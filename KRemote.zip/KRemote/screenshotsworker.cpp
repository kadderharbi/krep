/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#include "screenshotsworker.h"

screenshotsWorker::screenshotsWorker()
{
    isDirty = false;
}

void screenshotsWorker::run(void){
    while (true)
    {
        if (isDirty.load() == true)
        {
            //qDebug("9. screenshotsWorker: isDirty.load() == true. pendingScreenshot_mutex.lock()");
            { // lock_guard scope
                std::lock_guard<std::mutex> lock(pendingScreenshot_mutex);
                isDirty.store(false);
                pendingScreenshot_working_copy = pendingScreenshot.copy();
            } // lock_guard scope
            //qDebug("10. screenshotsWorker: isDirty set to false. pendingScreenshot_mutex.unlock()");

            if (this->pendingMsg.load() == this->protocol->MSG_SCREENSHOT_DIFF_REQUEST){
                this->prepareAndSendScreenshotDiff();
            }
            else
            {
                //first complete screenshot
                previousScreenshot=pendingScreenshot_working_copy;
                this->sendScreenshot(this->pendingScreenshot_working_copy,-1,-1);
            }
        }

        QThread::currentThread()->msleep(1);
    }
}

void screenshotsWorker::setScreenshot(QImage newScreenshot, const int msg)
{
    //QMutexLocker locker(&pendingScreenshot_mutex);

    //qDebug("7. Inside screenshotsWorker. Will set pendingScreenshot. pendingScreenshot_mutex.lock()");
    { // lock_guard scope
        std::lock_guard<std::mutex> lock(pendingScreenshot_mutex);
        pendingScreenshot = newScreenshot.copy();
        pendingMsg.store(msg);
        isDirty.store(true);
    } // lock_guard scope
   //qDebug("8. Inside screenshotsWorker. pendingScreenshot set. pendingScreenshot_mutex.unlock()");
}

void screenshotsWorker::prepareAndSendScreenshotDiff()
{
   //qDebug("11. screenshotsWorker.prepareAndSendScreenshotDiff called. Copy with previous one screenshot.");


    QImage outimg;

       //compare the previous screenshot and the current for differencies

       //TODO:  tuning algo becomes faster enough if

        int minx=pendingScreenshot_working_copy.width()+1;
        int maxx=-1;
        int miny=pendingScreenshot_working_copy.height()+1;
        int maxy=-1;
        int compareOffset = 4;
        //auto start = std::chrono::steady_clock::now();
        for (int ix=0;ix<pendingScreenshot_working_copy.width();ix+=compareOffset)
        {
             for (int iy=0;iy<pendingScreenshot_working_copy.height();iy+=compareOffset)
             {
                 if (previousScreenshot.pixel(ix,iy) != pendingScreenshot_working_copy.pixel(ix,iy)){
                     //there is difference in pixels
                     minx=std::min(minx,ix);
                     miny=std::min(miny,iy);
                     maxx=std::max(maxx,ix);
                     maxy=std::max(maxy,iy);
                     previousScreenshot.setPixel(ix,iy,pendingScreenshot_working_copy.pixel(ix,iy));
                 }
             }
        }



        //since the previous one and the current are not the same
        //send the half of their difference
        if (maxx>-1)
        {
            minx = minx - compareOffset + 1 < 0 ? 0 : minx - compareOffset + 1;
            miny = miny - compareOffset + 1 < 0 ? 0 : miny - compareOffset + 1;
            maxx = maxx + compareOffset - 1 > pendingScreenshot_working_copy.width() - 1 ? pendingScreenshot_working_copy.width() - 1 :maxx + compareOffset - 1;
            maxy = maxy + compareOffset - 1 > pendingScreenshot_working_copy.height() - 1 ? pendingScreenshot_working_copy.height() - 1 : maxy + compareOffset - 1;





            //auto end = std::chrono::steady_clock::now();
            //auto diff = end - start;
            //std::cout << std::chrono::duration<double,std::milli>(diff).count() << " ms" <<std::endl;
           //qDebug("12. screenshotsWorker.prepareAndSendScreenshotDiff  otherwise screenshot. Copying and preparing to send.");
           //qDebug("The screenshots are different. minx: %i,maxx: %i, miny: %i, maxy: %i",minx,maxx,miny,maxy);
            outimg=pendingScreenshot_working_copy.copy(minx,miny,maxx-minx+1,maxy-miny+1);
            sendScreenshot(outimg,minx,miny);

       }
       else
       {
           //qDebug("12. screenshotsWorker.prepareAndSendScreenshotDiff  same screenshot. Will send empty qimage");

           //The previousone with current is the same
           //so wait until there are some different ones
           QThread::currentThread()->msleep(50); //rest for 50 ms and wait for some changes

           sendScreenshot(outimg,0,0);

       }
}

void screenshotsWorker::sendScreenshot(QImage outimg,int x, int y)
{
    try
    {
        //qDebug("13. screenshotsWorker.sendScreenshot  called. Creation and compress of image bytes.");

        QByteArray bytes;
        QBuffer buffer(&bytes);
        buffer.open(QIODevice::WriteOnly);
        QImage locimg(outimg);
        locimg.save(&buffer,"JPG",this->imageQuality); // writes pixmap into bytes in PNG format

        int nSize = bytes.size();
         //qDebug("## image bytes size uncompressed: %i",nSize);

        QByteArray compressed_bytes = qCompress(bytes,9);
         //qDebug("## image bytes size commpressed: %i",compressed_bytes.size());

         std::array<char,1> cmd;

         std::vector<char> vimgbytes;
         if(pendingMsg.load() == protocol->MSG_SCREENSHOT_DIFF_REQUEST)
         {
             cmd[0] = 's';

             std::vector<char> cx(2);
             intToBytes(x,cx);
             vimgbytes.insert(vimgbytes.end(),cx.begin(),cx.end());
             //qDebug("x to send: %i",x);

             std::vector<char> cy(2);
             intToBytes(y,cy);
             vimgbytes.insert(vimgbytes.end(),cy.begin(),cy.end());
             //qDebug("y to send: %i",y);
         }
         else
         {
             cmd[0] = 'S';
         }

        vimgbytes.insert(vimgbytes.end(), compressed_bytes.begin(),compressed_bytes.end());

        //qDebug("14. screenshotsWorker.sendScreenshot ready image to send. Bytes: %lu", vimgbytes.size());

        protocol->_sendmsg(protocol->getActiveSocket(),cmd,vimgbytes);
        //qDebug("20. --->  screenshot diff mission completion.");

        vimgbytes.clear();
        vimgbytes.swap(vimgbytes);
    }
    catch (std::exception& ex)
    {
        //qDebug("EXCEPTION: void screenshotsWorker::sendScreenshot(QImage outimg,int x, int y), What: %s",ex.what());
    }
    catch ( ... )
    {
        //qDebug("EXCEPTION: void screenshotsWorker::sendScreenshot(QImage outimg,int x, int y)");
    }
}
