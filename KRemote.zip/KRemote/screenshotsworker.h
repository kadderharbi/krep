/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#ifndef SCREENSHOTSWORKER_H
#define SCREENSHOTSWORKER_H

#include "helperfuncs.h"
#include <QThread>
#include "clientserver.h"
#include <QImage>
#include <atomic>
#include <QMutexLocker>
#include <QBuffer>

//needed to take screenshot
#include <QGuiApplication>
#include <QScreen>
#include <QApplication>
#include <QDesktopWidget>
#include <qpaintengine.h>

class screenshotsWorker: public QThread
{
        Q_OBJECT
public:
    screenshotsWorker();
    void setScreenshot(QImage newScreenshot, const int msg);
    clientserver * protocol;
    std::atomic<int> imageQuality;

protected:
    void run(void);

private:
    QImage pendingScreenshot;
    QImage pendingScreenshot_working_copy;
    QImage previousScreenshot;
    std::atomic<int> pendingMsg;
    //std::recursive_mutex pendingScreenshot_mutex;
    std::mutex pendingScreenshot_mutex;
    std::atomic<bool> isDirty;
    void sendScreenshot(QImage outimg, int x, int y);
    void prepareAndSendScreenshotDiff();
};

#endif // SCREENSHOTSWORKER_H
