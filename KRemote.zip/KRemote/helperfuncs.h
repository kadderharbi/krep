/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#ifndef HELPERFUNCS_H
#define HELPERFUNCS_H

#include <vector>
#include <sstream>
//#include <QtGlobal> //

namespace helperfuncs{
    enum OS {
        Unknown = 0,
        Windows = 1,
        MacOS   = 2,
        Linux   = 3
    };

    void intToBytes(unsigned int value, std::vector<char> &buffer);
    unsigned int bytesToInt(const std::vector<char> &buffer);
    unsigned int bytesToInt(const std::vector<char> &buffer, unsigned int begin, unsigned int bytes);
    OS getOS();

}

#endif
