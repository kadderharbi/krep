/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "ui_mainwindow.h"
#include "screenshotsworker.h"
#include "clientserver.h"
#include <QMainWindow>
#include <QString>
#include "qdebug.h"
#include "qbytearray.h"
#include "qpixmap.h"
#include <QObject>
#include <QEvent>
#include <QPainter>
#include <QMouseEvent>
#include <QScreen>
#include <QDesktopWidget>
#include <math.h>       /* nearbyint */
#include <QMessageBox>
#include "mousekeyb/Mouse.h"
#include "mousekeyb/Keyboard.h"
#include <QMessageBox>
#include "keepalive.h"
#include <iostream>
#include "About.h"
#include <QDesktopServices>

//toolbar
#include"toolbar.h"

typedef std::vector<char> MyArray;
typedef std::string MyString;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void connectToServer();
    ~MainWindow();
    bool eventFilter(QObject *watched, QEvent *e);
    clientserver protocol;
    QImage lastScreenshot;
    screenshotsWorker screenshotWrk;
    keepalive keepAlive;
    About about;
    void update_window();
    std::vector<char> kdata;
    bool kresizable = false;
    void allowResize();

private slots:
    void mymessageRecieved(const int msgType, const std::vector<char>& vdata);
    void non_UI_thread_messageRecieved(const int msgType, const std::vector<char>& vdata);
    void protocol_exception(QString ex);
    void on_btnConnectToRemoteClient_clicked();
    void on_actionAbout_triggered();
    void slot_protocol_finished_or_terminated();

    void on_connectWidget_customContextMenuRequested(const QPoint &pos);
        void fix_window();
        void on_action_Exit_triggered();

        void on_action_Settings_triggered();

private:
    Ui::MainWindow *ui;
    void setDisabledRemoteControlWidgets(bool flag);
    QPoint lastMainWindowPosition;
    void setDefaultGUI();
    bool firstRun;
    //toolbar
    ToolBar* tb;
    bool is_fixed=false;
    QPixmap hand_cursor_pixmap =QPixmap("./cursor.png");  //Cursor to be attached with sent image for pointer cursor
    QPixmap ibeam_cursor_pixmap =QPixmap("./ibeam.png");  //Cursor to be attached with sent image for textinput cursor

protected:
    void closeEvent(QCloseEvent *event);
    void resizeEvent(QResizeEvent*);
    void mouseDoubleClickEvent(QMouseEvent*);
    void mousePressEvent(QMouseEvent*);
    void moveEvent(QMoveEvent*);

};


#endif
