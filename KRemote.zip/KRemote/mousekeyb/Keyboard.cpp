/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#include "Keyboard.h"


/*portableKeyboardModifier Keyboard::getPortableModifier (int key)
{
    switch (key)
    {
        case Qt::Key_Shift:
        return portableKeyboardModifier::Shift;
                break;
    case Qt::Key_Control:
        return portableKeyboardModifier::Control;
                break;
    case Qt::Key_Alt:
        return portableKeyboardModifier::Alt;
                break;
    case Qt::Key_Meta:
        return portableKeyboardModifier::Meta;
                break;
    //case Qt::key_key:
    //    return portableKeyboardModifier::Keypad;
    //            break;
    //case Qt::GroupSwitchModifier:
    //    return portableKeyboardModifier::GroupSwitch;
    //            break;
        default:
        return portableKeyboardModifier::NoModifier;
            break;
    }
}*/
/*
portableKeyboardModifier Keyboard::getPortableModifier (int key)
{
    switch (key)
    {
        case Qt::KeyboardModifier::ShiftModifier:
        return portableKeyboardModifier::Shift;
                break;
        case Qt::KeyboardModifier::ControlModifier:
        return portableKeyboardModifier::Control;
                break;
        case Qt::KeyboardModifier::AltModifier:
        return portableKeyboardModifier::Alt;
                break;
        case Qt::KeyboardModifier::MetaModifier:
        return portableKeyboardModifier::Meta;
                break;
        case Qt::KeyboardModifier::KeypadModifier:
        return portableKeyboardModifier::Keypad;
                break;
        case Qt::KeyboardModifier::GroupSwitchModifier:
        return portableKeyboardModifier::GroupSwitch;
                break;
        default:
        return portableKeyboardModifier::NoModifier;
            break;
    }
}*/
