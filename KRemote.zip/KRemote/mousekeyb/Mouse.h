/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#ifndef MOUSE_H
#define MOUSE_H

#include <thread>
#include <QtGlobal>
#include <QtEvents>
#include <QDebug>

class Mouse {
public:
    // fails if given coordinates are not in the screen's rect
    // Linux: fails if there is an opening X display error
    static void moveToPoint(const int x, const int y);

    static void doubleClick(Qt::MouseButton button);

    // fails if the given button is not Qt::LeftButton, Qt::RightButton or Qt::MiddleButton
    // Linux: fails if there is an opening X display error
    static void press(Qt::MouseButton button);
    static void release(Qt::MouseButton button);

    // Linux: fails if there is an opening X display error
    static void scroll(int value); //positive values for scrolling up, negative for scrolling down

private:
    static Qt::MouseButtons bp;
    static void selectArea(const int x, const int y);
};
#endif // MOUSE_H
