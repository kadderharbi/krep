/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <QCursor>
#include <unordered_map>
#include <QKeyEvent>

#ifdef _WIN32
#include <windows.h>
#define VIRTUAL_TO_SCAN_CODE 0
#endif
enum portableKeyboardModifier
{
    NoModifier = 0,
    Shift = 1,
    Control = 2,
    Alt = 4,
    Meta = 8,
    Keypad = 16,
    GroupSwitch = 32
};

enum portableVKey
{
    PVK_UNKNOWN = -0x01,
    PVK_TAB          = 0x01000001,
    PVK_CLEAR        = 0x0c,
    PVK_RETURN       = 0x0d,
    PVK_ENTER        = 0x01000004,    
    PVK_ESCAPE       = 0x01000000,
    PVK_PAGE_UP      = 0x01000016, // PRIOR
    PVK_PAGE_DOWN    = 0x01000017, // NEXT
    PVK_END          = 0x01000011,
    PVK_HOME         = 0x01000010,
    PVK_LEFT        =0x01000012,
    PVK_UP           = 0x01000013,
    PVK_RIGHT        = 0x01000014,
    PVK_DOWN         = 0x01000015,
    PVK_BACK         = 0x01000003,

    PVK_INSERT       = 0x01000023,
    PVK_DELETE       = 0x01000007,
    PVK_CAPSLOCK    = 0x01000024,
    PVK_F1           = 0x01000030,
    PVK_F2           = 0x01000031,
    PVK_F3           = 0x01000032,
    PVK_F4           = 0x01000033,
    PVK_F5           = 0x01000034,
    PVK_F6           = 0x01000035,
    PVK_F7           = 0x01000036,
    PVK_F8           = 0x01000037,
    PVK_F9           = 0x01000038,
    PVK_F10          = 0x01000039,
    PVK_F11          = 0x0100003a,
    PVK_F12          = 0x0100003b,
    PVK_F13          = 0x0100003c,
    PVK_F14          = 0x0100003d,
    PVK_F15          = 0x0100003e,
    PVK_F16          = 0x0100003f,

    PVK_NUMLOCK      = 0x01000025,



};

class Keyboard {
public:
#ifdef Q_OS_WIN
    static INPUT getKeyEvent(int key, bool keyUp = false);
#endif

    static void keyPress(int key, int modifiers);
    static void keyRelease(int key, int modifiers);
    //static portableKeyboardModifier getPortableModifier(int key);
    //static portableVKey getPortableVKey(int key, int qtkey);
    //static int convertPortableKeyToLocal(portableVKey portableKey);

private:
    std::unordered_map<int,int> Keys;
    //static bool Caps;
};

#endif // KEYBOARD_H
