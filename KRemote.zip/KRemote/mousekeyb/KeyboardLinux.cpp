/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#include "Keyboard.h"

#ifdef Q_OS_LINUX
#define XK_LATIN1;
#define XK_MISCELLANY;
#include <X11/keysymdef.h>
#include <X11/extensions/XTest.h>
#include<iostream>


using namespace std;

int shift_pressed=0;
int ctrl_pressed = 0;
int super_pressed =0;
int alt_pressed=0;

string get_command(int key){
    switch(key){
    // Letters
    case XK_A:
            return "a";
    case XK_B:
        return "b";
    case XK_C:
        return "c";
    case XK_D:
        return "d";
    case XK_E:
        return "e";
    case XK_F:
        return "f";
    case XK_G:
        return "g";
    case XK_H:
        return "h";
    case XK_I:
        return "i";
    case XK_J:
        return "j";
    case XK_K:
        return "k";
    case XK_L:
        return "l";
    case XK_M:
        return "m";
    case XK_N:
        return "n";
    case XK_O:
        return "o";
    case XK_P:
        return "p";
    case XK_Q:
        return "q";
    case XK_R:
        return "r";
    case XK_S:
        return "s";
    case XK_T:
        return "t";
    case XK_U:
        return "u";
    case XK_V:
        return "v";
    case XK_W:
        return "w";
    case XK_X:
        return "x";
    case XK_Y:
        return "y";
    case XK_Z:
        return "z";

    //Numbers
    case XK_0:
        return "0";
    case XK_1:
        return "1";
    case XK_2:
        return "2";
    case XK_3:
        return "3";
    case XK_4:
        return "4";
    case XK_5:
        return "5";
    case XK_6:
        return "6";
    case XK_7:
        return "7";
    case XK_8:
        return "8";
    case XK_9:
        return "9";

    //Operators

    // +
    case XK_plus:
    case XK_KP_Add:
        return "plus";

    // -
    case XK_minus:
        return "minus";

    // *
    case XK_asterisk:
    case XK_KP_Multiply:
        return "asterisk";

    // /
    case XK_slash:
    case XK_KP_Divide:
        return "slash";

    // backslash
    case XK_backslash:
        return "backslash";

    // |
    case XK_bar:
        return "bar";

    // =
    case XK_equal:
        return "equal";

    // space
    case XK_space:
        return "space";


    // Enter | Return
    case portableVKey::PVK_RETURN:
    case portableVKey::PVK_ENTER:
    case XK_KP_Enter:
        return "KP_Enter";

    //  Backspace
    case portableVKey::PVK_BACK:
    case XK_BackSpace:
        return "BackSpace";
    case portableVKey::PVK_END:
    case XK_End:
        return "End";
    case portableVKey::PVK_HOME:
    case XK_Home:
        return "Home";
    case portableVKey::PVK_PAGE_UP:
    case XK_Page_Up:
        return "Page_Up";
    case portableVKey::PVK_PAGE_DOWN:
    case XK_Page_Down:
        return "Page_Down";
    case portableVKey::PVK_DELETE:
    case XK_Delete:
        return "Delete";
    case XK_bracketleft:
        return "bracketleft";
    case XK_bracketright:
        return "bracketright";
    case XK_braceleft:
        return "braceleft";
    case XK_braceright:
        return "braceright";

    //Marks

    // ,
    case XK_comma:
        return "comma";
    // ;
    case XK_semicolon:
        return "semicolon";
    // .

    // :
    case XK_colon:
        return "colon";

    case XK_period:
        return "period";

    // !
    case XK_exclam:
        return "exclam";

    // ?
    case XK_question:
        return "question";


    case XK_quoteleft:
        return "quoteleft";
    case XK_quoteright:
        return "quoteright";
    case XK_quotedbl:
        return "quotedbl";

   //Directions
    case portableVKey::PVK_LEFT:
        return "Left";
    case portableVKey::PVK_RIGHT:
        return "Right";
    case portableVKey::PVK_UP:
        return "Up";
    case portableVKey::PVK_DOWN:
        return "Down";
    case portableVKey::PVK_TAB:
    case XK_Tab:
        return "Tab";


    //Special characters

    case XK_parenleft:          //left parenthesis
        return "9";
    case XK_parenright:         //right parenthesis
        return "0";
    case XK_ampersand:          //ampersand &
        return "7";
    case XK_Escape:             //escape
    case 0x01000000:
        return "Escape";


    case XK_at:
        return "at";            //at @
    case XK_numbersign:
        return "numbersign";    //numbersign #
    case XK_dollar:
        return "dollar";        //dollar $
    case XK_percent:
        return "percent";       //precent %
    case XK_asciicircum:
        return "asciicircum";   //asciicircum ^
    case XK_underscore:
        return "underscore";    //underscore
    case XK_asciitilde:         //tilde ~
        return "asciitilde";

    //Default  key
        default:
            return "";
    }
}

void process_command(int key){
    string cmd = get_command(key);
    if(cmd == "")return;
    string _cmd = "./xdotool key ";
    if(shift_pressed)
        _cmd = _cmd+"shift+";
    if(ctrl_pressed)
        _cmd=_cmd+"ctrl+";
    if(super_pressed)
        _cmd=_cmd+"super+";
    if(alt_pressed)
        _cmd=_cmd+"alt+";
    _cmd=_cmd+cmd;
    qDebug("Processed : %s",_cmd.data());
    qDebug("Key pressed : %i\n",key);
    system(_cmd.data());
}

void Keyboard::keyPress(int key, int modifiers)
{
    //if(modifiers==1)
     switch(key){
        case 16777248://shift
            shift_pressed=1;break;
        case 16777249:
            ctrl_pressed=1;break;
        case 16777251://alt
            alt_pressed=1;break;
        case 16777250://super
            super_pressed=1;break;

    }
    process_command(key);
qDebug("-----------------------------------%i---------------------------------------",key);

}

void Keyboard::keyRelease(int key, int modifiers)
{
   //if(modifiers==1)
   switch(key){
       case 16777248://shift
           shift_pressed=0;break;
       case 16777249:
           ctrl_pressed=0;break;
        case 16777251://alt
            alt_pressed=0;break;
        case 16777250://super
            super_pressed=0;break;
       }
   qDebug("-----------------------------------%i---------------------------------------",key);
}

#endif

