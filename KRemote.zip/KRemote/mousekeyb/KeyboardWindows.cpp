/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#include "Keyboard.h"

#ifdef _WIN32
void Keyboard::keyPress(int key, int modifiers) {
    /*
    if (modifiers) {
        INPUT input = getKeyEvent(modifiers);
        SendInput(1, &input, sizeof(input));
    }
    */

    INPUT input = getKeyEvent(key);
    SendInput(1, &input, sizeof(input));
}

void Keyboard::keyRelease(int key, int modifiers)
{
    /*
    if (modifiers) {
        INPUT input = getKeyEvent(modifiers, true);
        SendInput(1, &input, sizeof(input));
    }
    */

    INPUT input = getKeyEvent(key, true);
    SendInput(1, &input, sizeof(input));
}

INPUT Keyboard::getKeyEvent(int key, bool keyUp) {

    INPUT event;
    event.type = INPUT_KEYBOARD;
    event.ki.wVk = key;
    event.ki.wScan = MapVirtualKey(key, VIRTUAL_TO_SCAN_CODE);
    event.ki.dwFlags = keyUp ? KEYEVENTF_KEYUP : 0;
    event.ki.time = 0;
    event.ki.dwExtraInfo = 0;

    return event;
}

portableVKey Keyboard::getPortableVKey(int key, int qtkey)
{
    return (portableVKey)key;
}

int Keyboard::convertPortableKeyToLocal(portableVKey portableKey)
{
    return portableKey;
}

#endif
