/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#include "clientserver.h"

std::vector<char> myID;

const std::array<char,1> CMD_PROTOCOL = {{'P'}};
const std::array<char,1> CMD_CONNECT = {{'C'}};
const std::array<char,1> CMD_CONNECT_ID_NOT_FOUND = {{'c'}}; //When the remote ID is not found
const std::array<char,1> CMD_QUIT = {{'Q'}};
const std::array<char,1> CMD_ACCEPT = {{'A'}};
const std::array<char,1> CMD_ID = {{'I'}};
const std::array<char,1> CMD_SCREENSHOT = {{'S'}};
const std::array<char,1> CMD_SCREENSHOT_DIFF = {{'s'}};
const std::array<char,1> CMD_REQUEST_SCREENSHOT = {{'R'}};
const std::array<char,1> CMD_REQUEST_SCREENSHOT_DIFF = {{'r'}};
const std::array<char,1> CMD_MOUSE = {{'M'}}; // Mouse command
const std::array<char,1> CMD_KEYBOARD = {{'K'}}; // Keyboard command
const std::array<char,1> CMD_DISCONNECT_FROM_REMOTE_COMPUTER = {{'D'}}; // Disconnect from remote computer
const std::array<char,1> CMD_HEART_BEAT = {{'H'}};
const std::array<char,1> CMD_BAN_IP_WRONG_ID = {{'B'}}; // BAN IP Wrong ID 5 bytes
const std::array<char,1> CMD_WARNING_BAN_IP_WRONG_ID= {{'W'}}; // Warn IP Wrong ID 2 bytes
const std::array<char,1> CMD_CONNECT_PASSWORD_NOT_CORRECT= {{'p'}}; // When Remote password is not OK 1 byte
const std::array<char,1> CMD_BAN_IP_WRONG_PWD = {{'b'}}; //BAN IP Wrong password 2 byte
const std::array<char,1> CMD_WARNING_BAN_IP_WRONG_PWD= {{'w'}}; // Warn IP Wron password 2 byte
const std::array<char,1> CMD_ERROR_APP_VERSION_NOT_ACCEPTED = {{'V'}}; // When the app version is wrong
const std::array<char,1> CMD_ERROR_PROTOCOL_VERSION_NOT_ACCEPTED = {{'v'}}; // When the protocol wrong

clientserver::clientserver()
{
    setRemoteComputerOS(OS::Unknown);
}

void clientserver::run(void)
{
    emit sig_fixwindow();
   this->start_protocol();

}


#ifdef WIN32
void clientserver::setActiveSocket(const SOCKET socket)
#else
void clientserver::setActiveSocket(const int socket)
#endif
{
    this->_activeSocket = socket;
}

#ifdef WIN32
SOCKET clientserver::getActiveSocket()
#else
int clientserver::getActiveSocket()
#endif
{
    return this->_activeSocket;
}

void clientserver::error(const char *msg)
{
    std::cout << "ERROR " << msg <<  "\n";
    perror(msg);
    //exit(0);
}

#ifdef WIN32
void clientserver::cleanup(const SOCKET socketfd)
#else
void clientserver::cleanup(const int socketfd)
#endif
{}

//Display error number to source
void clientserver::displayErrno(std::string source)
{
#ifdef WIN32
    int ilasterror = WSAGetLastError();
    std::cout << std::this_thread::get_id() << " " <<
                 "###### [source: " << source <<  "]  displayErrno - WSAGetLastError: " << strerror(ilasterror) << std::endl;
#else
    int ilasterror = errno;
    std::cout << std::this_thread::get_id() << " " <<
                 "###### [source: " << source <<  "]  displayErrno - errno: " << strerror(ilasterror) << std::endl;
#endif
}


//Sends the life heart beat
void clientserver::sendHeartBeat()
{
    _sendmsgPlain(this->getActiveSocket(),CMD_HEART_BEAT);
}


// Sets remote computer Operating System
void clientserver::setRemoteComputerOS(OS os)
{
    _remoteComputerOS = os;
}

// Gets remote Operating System
OS clientserver::getRemoteComputerOS()
{
    return _remoteComputerOS;
}


//Send the keyboeard code
void clientserver::sendKeyboard(int portableVKey, int portableModifiers, int keyEvent)
{
    //4 bytes portableVKey
    //1 byte portableModifiers
    //1 byte keyEvent (1 press, 2 release)
    std::vector<char> msg(6);

    std::vector<char> _portableVKey(4);
    intToBytes(portableVKey,_portableVKey);
    msg[0] = _portableVKey[0];
    msg[1] = _portableVKey[1];
    msg[2] = _portableVKey[2];
    msg[3] = _portableVKey[3];

    std::vector<char> _portableModifiers(1);
    intToBytes(portableModifiers,_portableModifiers);
    msg[4] = _portableModifiers[0];

    std::vector<char> _keyEvent(1);
    intToBytes(keyEvent,_keyEvent);
    msg[5] = _keyEvent[0];

    _sendmsgPlain(this->getActiveSocket(),CMD_KEYBOARD,msg);
}

// Sends the mouse events
void clientserver::sendMouse(int x, int y, int button,int mouseEvent, int wheelDelta,int wheelDeltaSign, int wheelOrientation)
{
    //x 2 bytes
    //y 2 bytes
    //button 1 byte (0 kanena, 1=left, 2=middle, 4 right...)
    //buttonState 1 byte (0 aprosdioristo, 1 press, 2 release)
    //wheel 2 bytes

    std::vector<char> msg(10);

    std::vector<char> _xpos(2);
    intToBytes(x,_xpos);
    msg[0] = _xpos[0];
    msg[1] = _xpos[1];

    std::vector<char> _ypos(2);
    intToBytes(y,_ypos);
    msg[2] = _ypos[0];
    msg[3] = _ypos[1];

    std::vector<char> _btn(1);
    intToBytes(button,_btn);
    msg[4] = _btn[0];

    std::vector<char> _mouseEvent(1);
    intToBytes(mouseEvent,_mouseEvent);
    msg[5] = _mouseEvent[0];

    std::vector<char> _wheelDelta(2);
    intToBytes(wheelDelta,_wheelDelta);
    msg[6] = _wheelDelta[0];
    msg[7] = _wheelDelta[1];

    std::vector<char> _wheelDeltaSign(1);
    intToBytes(wheelDeltaSign,_wheelDeltaSign);
    msg[8] = _wheelDeltaSign[0];

    std::vector<char> _wheelOrientation(1);
    intToBytes(wheelOrientation,_wheelOrientation);
    msg[9] = _wheelOrientation[0];

    _sendmsgPlain(this->getActiveSocket(),CMD_MOUSE,msg);
}


// Sets connection state
void clientserver::setConnectionState(connectionState state)
{
    std::lock_guard<std::mutex> lock(connection_state_mutex);
    m_connection_state = state;
}

// Gets connection state
connectionState clientserver::getConnectionState()
{
    std::lock_guard<std::mutex> lock(connection_state_mutex);
    return m_connection_state;
}


// Sends Disconnect from remote computer
void clientserver::sendDisconnectFromRemoteComputer()
{
    //1 byte
     setConnectionState(connectionState::connectedWithProxy);
    _sendmsgPlain(this->getActiveSocket(),CMD_DISCONNECT_FROM_REMOTE_COMPUTER);
}


// Sends the plain Msg defined depending of OS

#ifdef WIN32
int clientserver::_sendmsgPlain(const SOCKET socketfd, const std::array<char, 1> &command, const std::vector<char> &message)
#else
int clientserver::_sendmsgPlain(const int socketfd, const std::array<char, 1> &command,const std::vector<char> &message)
#endif
{

    std::vector<char> msg(1);
    msg[0]=command[0];

    if (message.size() > 0){
        msg.insert(msg.begin()+1, message.begin(),message.end());
    }

    int total = 0;        // how many bytes we've sent
    {
        // lock_guard scope
        std::lock_guard<std::mutex> lock(sendmutex);

        size_t bytesleft = msg.size(); // how many bytes left to send
        int n;
        while (total < msg.size()){     
            n = send(socketfd,msg.data()+total,bytesleft,0);
            if (n < 0){
                displayErrno("bytes send < 0 ----> int clientserver::_sendmsgPlain(const int socketfd, const std::array<char, 1> &command,const std::vector<char> &message)");
                break;
            }
            else if (n == 0)
            {
                std::cout << "-----> send returned 0 bytes. Expected: " << msg.size() <<
                             "  [ int clientserver::_sendmsgPlain(int socketfd, const std::array<char, 1> &command,const std::vector<char> &message) ]" << std::endl;
                displayErrno("int clientserver::_sendmsgPlain(int socketfd, const std::array<char, 1> &command,const std::vector<char> &message)");
                return 0;
            }
            total+=n;
            bytesleft-=n;
        }

        //sendmutex.unlock();
    } // lock_guard scope

    if (total != (int)msg.size()){
        std::cout << "----> throw EXCEPTION IN int clientserver::_sendmsgPlain(int socketfd, const std::array<char, 1> &command,const std::vector<char> &message). Bytes send not equal to bytes expected." << std::endl;
        cleanup((socketfd));
        throw std::runtime_error(std::string("----> throw EXCEPTION IN int clientserver::_sendmsgPlain(int socketfd, const std::array<char, 1> &command,const std::vector<char> &message). Bytes send not equal to bytes expected."));
    }
    return total;
}


// Sends msg defined depending of OS

#ifdef WIN32
int clientserver::_sendmsg(const SOCKET socketfd, const std::array<char, 1> &command, const std::vector<char> &message)
#else
int clientserver::_sendmsg(const int socketfd,    const std::array<char, 1> &command, const std::vector<char> &message)
#endif
{
    //qDebug("15. clientserver::sendmsg called");

    std::vector<char> msg(5);
    int len = message.size();

    //qDebug("16. Message len: %i",len);

    std::vector<char> lenb(4);
    intToBytes(len,lenb);

    msg[0]=command[0];
    msg[1]=lenb[0];
    msg[2]=lenb[1];
    msg[3]=lenb[2];
    msg[4]=lenb[3];

    msg.insert(msg.begin()+5, message.begin(),message.end());

    int total = 0;        // how many bytes we've sent
                          //qDebug("17. Will lock send socket (sendmutex)");
    {
        // lock_guard scope
        std::lock_guard<std::mutex> lock(sendmutex);        

        size_t bytesleft = msg.size(); // how many bytes left to send
        int n;
        while (total < msg.size()){
            n = send(socketfd,msg.data()+total,bytesleft,0);
            if (n < 0){
                break;
            }
            else if (n == 0)
            {
                std::cout << "-----> send returned 0 bytes. Expected: " << msg.size() <<
                             "  [ int clientserver::_sendmsg(int socketfd,    const std::array<char, 1> &command, const std::vector<char> &message) ]" << std::endl;
                displayErrno("int clientserver::_sendmsg(int socketfd,    const std::array<char, 1> &command, const std::vector<char> &message)");
                return 0;
            }
            total+=n;
            bytesleft-=n;
        }

        //qDebug("19. Command: %s send. Total bytes returned from socket: %i",&msg[0],total);
        //sendmutex.unlock();
    } // lock_guard scope
    //qDebug("############ 19. send socket unlocked (sendmutex). END");

    if (total != (int)msg.size()){
        std::cout << "----> throw EXCEPTION IN size_t int clientserver::_sendmsg(int socketfd,    const std::array<char, 1> &command, const std::vector<char> &message). Bytes send not equal to bytes expected." << std::endl;
        cleanup((socketfd));
        throw std::runtime_error(std::string("----> throw EXCEPTION IN size_t int clientserver::_sendmsg(int socketfd,    const std::array<char, 1> &command, const std::vector<char> &message). Bytes send not equal to bytes expected."));
    }
    return total;
}



// Receives Plain Msg defined depending of OS
#ifdef WIN32
int clientserver::_receivePlain(const SOCKET socketfd, std::vector<char> &charbuffer)
#else
int clientserver::_receivePlain(const int socketfd, std::vector<char> &charbuffer)
#endif
{
    size_t bytes_cnt_payload=0;

    while(bytes_cnt_payload < charbuffer.size())
    {
        int bytes_rcv_payload = recv(socketfd,charbuffer.data() + bytes_cnt_payload,charbuffer.size() - bytes_cnt_payload, 0);

        if (bytes_rcv_payload == 0){
            std::cout << std::this_thread::get_id() << " " <<
                       "####  int recieve: recv return 0 bytes. [int clientserver::_receivePlain(int socketfd, std::vector<char> &charbuffer)]. Returning from function." << std::endl;
            return 0;
        }
        else if (bytes_rcv_payload == -1){
            displayErrno("int clientserver::_receivePlain(int socketfd, std::vector<char> &charbuffer)");
            return -1;
        }

        bytes_cnt_payload += bytes_rcv_payload;
    }

    if (bytes_cnt_payload != charbuffer.size()){
        std::cout << "----> EXCEPTION IN recieve func int clientserver::_receivePlain(int socketfd, std::vector<char> &charbuffer). Bytes recieved not equal to bytes expected. Expected: " << charbuffer.size() << " recieved: " << bytes_cnt_payload << std::endl;
        throw std::runtime_error(std::string("----> EXCEPTION IN recieve func (payload). Bytes recieved not equal to bytes expected.\n"));
    }

    return bytes_cnt_payload;
}


//Receives Msg

#ifdef WIN32
int clientserver::_receive(const SOCKET socketfd, std::vector<char> &charbuffer)
#else
int clientserver::_receive(const int socketfd, std::vector<char> &charbuffer)
#endif
{
    //The first part : Receive the total of bytes where are expected at payload
    size_t bytes_needed = 4;
    std::vector<char> len_bytes(4);
    size_t bytes_cnt=0;

    while(bytes_cnt < bytes_needed)
    {
        int bytes_rcv = recv(socketfd, len_bytes.data() + bytes_cnt, bytes_needed - bytes_cnt, 0);

        if (bytes_rcv == 0){
            std::cout << std::this_thread::get_id() << " " <<
                       "####  int recieve: recv return 0 bytes. [first while loop]. Returning from function." << std::endl;
            return 0;
        }
        else if (bytes_rcv == -1){
            displayErrno("int clientserver::_receive(int socketfd, std::vector<char> &charbuffer) - first while loop");
            return -1;
        }

        bytes_cnt += bytes_rcv;
    }

    if (bytes_needed != bytes_cnt){
        std::cout << "----> EXCEPTION IN recieve func (payload length). Bytes recieved not equal to bytes expected. Expected: " << bytes_needed << " recieved: " << bytes_cnt << std::endl;
        throw std::runtime_error(std::string("----> EXCEPTION IN recieve func (payload length). Bytes recieved not equal to bytes expected."));
    }

    //-----------

    //The secont part: receive the payload
    size_t bytes_needed_payload = bytesToInt(len_bytes);
    //Resize the bytes_needed_playload if it overgoes 20MB
    if (bytes_needed_payload < 20971520){ //maximum 20 MB
        charbuffer.resize(bytes_needed_payload);
    }
    else {
        std::cout << "Error on _receive: cannot receive more than 20971520 bytes at once" << std::endl;
        throw std::runtime_error("_receive > cannot receive more than 20971520 bytes at once");
    }
    size_t bytes_cnt_payload = 0;

    while(bytes_cnt_payload < bytes_needed_payload)
    {
        int bytes_rcv_payload = recv(socketfd,charbuffer.data() + bytes_cnt_payload,bytes_needed_payload - bytes_cnt_payload, 0);

        if (bytes_rcv_payload == 0){
            std::cout << std::this_thread::get_id() << " " <<
                       "####  int recieve: recv return 0 bytes. [second while loop]. Returning from function." << std::endl;
            return 0;
        }
        else if (bytes_rcv_payload == -1){
            displayErrno("int clientserver::_receive(int socketfd, std::vector<char> &charbuffer) - second while loop");
            return -1;
        }

        bytes_cnt_payload += bytes_rcv_payload;
    }

    if (bytes_cnt_payload != bytes_needed_payload){
        std::cout << "----> EXCEPTION IN recieve func (payload). Bytes recieved not equal to bytes expected. Expected: " << bytes_needed_payload << " recieved: " << bytes_cnt_payload << std::endl;
        throw std::runtime_error(std::string("----> EXCEPTION IN recieve func (payload). Bytes recieved not equal to bytes expected."));
    }

    return bytes_cnt_payload + bytes_cnt;
}

//Connect to another computer
void clientserver::Connect(const std::vector<char> &remoteID, const std::vector<char> &remotePassword){

    //Can't connect to the same ID
    if (myID == remoteID){
        emit sig_messageRecieved(MSG_ERROR_CANNOT_CONNECT_SAME_ID);
        return;
    }

    std::vector<char> data;
    createConnectCommandData(data, remoteID, remotePassword);
    _sendmsg(this->getActiveSocket(),CMD_CONNECT,data);   // Sends connection request
}
void clientserver::RequestScreenshot(){
    _sendmsgPlain(this->getActiveSocket(),CMD_REQUEST_SCREENSHOT);
}
void clientserver::RequestScreenshotDiff(){
    diffRequestCounter++;
    std::string cnt = std::to_string(diffRequestCounter);
    std::vector<char> msg(cnt.begin(),cnt.end());
    _sendmsg(this->getActiveSocket(),CMD_REQUEST_SCREENSHOT_DIFF,msg);
    //qDebug ("Egine apostoli aitimatos CMD_REQUEST_SCREENSHOT_DIFF me ID: %s kai perimeno to screenshot diff.",cnt.c_str());
    //_sendmsg(localsocket,CMD_REQUEST_SCREENSHOT_DIFF,1);
}


// Generate random password
std::string clientserver::generateRandomPassword(int length)
{    
    std::string result;
    result.resize(length);

    for (int i = 0; i < length; i++){
        int d = distribution(mt);
        result[i] = passwordCharset[d];
    }

    return result;
}

//Test if IP banned for wrong password

bool clientserver::isIPBannedForWrongPasswords(in_addr_t clientIP)
{
    std::lock_guard<std::mutex> lock(protect_password_mutex);

    if (protect_password.count(clientIP) == 0){
        //If the IP is not correct
        return false;
    }

    // clientIP found

    PasswordProtection & pwprotect = protect_password[clientIP];
    if (pwprotect.wrongIDCounter >= MAX_WRONG_PWD_TRIES){
        // *** BAN ***
        // became ban.
        // inform the client
        _sendmsgPlain(this->getActiveSocket(),CMD_BAN_IP_WRONG_PWD);
        return true;
    }

    //not cecame ban
    return false;
}

void clientserver::resetWrongPasswordIPProtection(in_addr_t clientIP)
{
    std::lock_guard<std::mutex> lock(protect_password_mutex);

    if (protect_password.count(clientIP) != 0){
        //ClientIP not found
        PasswordProtection & pwprotect = protect_password[clientIP];
        pwprotect.wrongIDCounter = 0;
    }
}

bool clientserver::addWrongPasswordIPProtection(in_addr_t clientIP)
{
    std::lock_guard<std::mutex> lock(protect_password_mutex);

    if (protect_password.count(clientIP) == 0){
        //clientIP not found
        //so we register the ip whose password is
        //and init its values
        PasswordProtection pwprotect;
        pwprotect.wrongIDCounter = 1;
        protect_password[clientIP] = pwprotect;

        //also inform the client who made the request
        _sendmsgPlain(this->getActiveSocket(),CMD_CONNECT_PASSWORD_NOT_CORRECT);

        return true;
    }
    else {
        //clientIP found
        //Check if done or not
        PasswordProtection & pwprotect = protect_password[clientIP];
        pwprotect.wrongIDCounter++;

        //Check the max password tries
        if (pwprotect.wrongIDCounter >= MAX_WRONG_PWD_TRIES){
            // *** BAN ***
            //Exceeded the max limit tries
            //inform the client
            _sendmsgPlain(this->getActiveSocket(),CMD_BAN_IP_WRONG_PWD);
            return false;
        }
        else {
            //still can try
            //Send warning to the client about attempts limit remained
            if (pwprotect.wrongIDCounter >= MAX_WRONG_PWD_TRIES_WARNING){
                //warning send
                int remain = MAX_WRONG_PWD_TRIES - pwprotect.wrongIDCounter;
                std::vector<char> vremain(1);
                intToBytes(remain, vremain);
                _sendmsgPlain(this->getActiveSocket(),CMD_WARNING_BAN_IP_WRONG_PWD,vremain);
                return true;
            }
            else {
                //Mistakes not reached yet
                //inform the client who made the request that password not correct
                _sendmsgPlain(this->getActiveSocket(),CMD_CONNECT_PASSWORD_NOT_CORRECT);

                return true;
            }
        }
    }
}

/* To connect one computer to another, must send the ID so that
 * the other knows who is it (Useful in case a side change occurs)
 * and password of the other computer to make authentication.
 * It forms the command as follows:
 * //| 1 byte command | 4 byte msg payload | 1 byte which identifies ID length_1 | ID with bytes of length_1 | password with bytes as l as payload - length_1 |
 *| 1 byte command | 4 byte msg payload | 1 byte msg type (0=proxy, 1=direct) | 1 byte which determines the ID length_1 | ID with bytes of length_1 | 1 byte password length_2 | password with bytes of length_2 | IP 4 as l as payload - length_1 - length_2 - 3 |
 * The field its IP adds it proxy
 */
void clientserver::createConnectCommandData(std::vector<char> &all_data, const std::vector<char> &remoteComputerID, const std::vector<char> &remoteComputerPassword)
{
    //1 byte msg type
    std::vector<char> connMsgTypeSize(1);
    intToBytes(connectMessageType::proxy, connMsgTypeSize);
    all_data.insert(all_data.begin(),connMsgTypeSize[0]); // size of connMsgTypeSize

    //1 byte OS
    std::vector<char> connOSSize(1);
    intToBytes(getOS(), connOSSize);
    all_data.insert(all_data.end(),connOSSize[0]); // the current functional

    //ID size and ID registration
    std::vector<char> idSize(1);
    intToBytes(remoteComputerID.size(),idSize);
    all_data.insert(all_data.end(), idSize[0]); // size of ID
    all_data.insert(all_data.end(), remoteComputerID.begin(), remoteComputerID.end()); // the ID

    //PWD size and PWD registration
    std::vector<char> pwdSize(1);
    intToBytes(remoteComputerPassword.size(),pwdSize);
    all_data.insert(all_data.end(), pwdSize[0]); // size of PWD
    all_data.insert(all_data.end(), remoteComputerPassword.begin(), remoteComputerPassword.end()); // the PWD
}

void clientserver::proccesCommand(const std::array<char, 1> &command){

    if(command == CMD_PROTOCOL)
    {

        //The server sends the version of protocol it supports
        //in the form "P<major><minor>" where major,minor of one byte.
        //total command 3 bytes
        std::vector<char> protocolbuff(2);
        _receivePlain(this->getActiveSocket(), protocolbuff);
        qDebug("Server protocol: v%s.%s",&protocolbuff[0],&protocolbuff[1]);

        //The server sends the protocol that it supports
        std::vector<char> client_appver_and_protocolver(7);

        //app version
        client_appver_and_protocolver[0] = '0';
        client_appver_and_protocolver[1] = '1';
        client_appver_and_protocolver[2] = '0';

        //protocol version
        client_appver_and_protocolver[3] = '0';
        client_appver_and_protocolver[4] = '1';
        client_appver_and_protocolver[5] = '0';

        std::vector<char> cachedIDSize(1);
        intToBytes(cachedID.size(),cachedIDSize);
        client_appver_and_protocolver[6] = cachedIDSize[0];

        if (cachedID.size() > 0){

            client_appver_and_protocolver.insert(client_appver_and_protocolver.begin()+7,cachedID.begin(),cachedID.end());
        }

        //Send application verbosity, protocol, and any formats in the form:
        //<CMD_PROTOCOL> <client_appver_and_protocolver 6 bytes> <cachedID length 1 bytes> <cachedID>
        //_sendmsgPlain(this->getActiveSocket(),CMD_PROTOCOL,client_appver_and_protocolver);
        _sendmsg(this->getActiveSocket(),CMD_PROTOCOL,client_appver_and_protocolver);
    }

    else if(command == CMD_ID)
    {

        //efoson o server apodextei to protocol verion
        //if the server accepts the ... protocol
        //sends to the  client in the form: I<plength><id>

        //Takes the following:
        //<1 byte id length><id><1 byte cachedID lenght><cached id>

        std::vector<char> cmdIDdataBuff;
        _receive(this->getActiveSocket(),cmdIDdataBuff); // <--------------------- the client id that is sent to server

        //Get the size of the client id
        int idLength = bytesToInt(cmdIDdataBuff,0,1);
        myID = std::vector<char> (cmdIDdataBuff.begin()+1,cmdIDdataBuff.begin()+1+idLength);


        int cached_idLength = bytesToInt(cmdIDdataBuff,idLength+1,1);
        cachedID = std::vector<char> (cmdIDdataBuff.begin()+1+1+idLength,cmdIDdataBuff.begin()+1+1+idLength+cached_idLength);

        std::cout << "Client ID recieved from server: " << myID.data() << std::endl;
        //std::vector<char> emtpyv;
        setConnectionState(connectionState::connectedWithProxy);
        emit sig_messageRecieved(MSG_ID, myID);

        if (password.size() == 0){ //If the password has not been created, create it
            password = generateRandomPassword();
            emit sig_messageRecieved(MSG_LOCAL_PASSWORD_GENERATED);
        }
    } // CMD_ID


    else if(command == CMD_CONNECT)  // Then start connection processs
    {
        std::vector<char> remote_client_idbuff;
        _receive(this->getActiveSocket(),remote_client_idbuff); // <-----------the remote client id where to connect

        //The type of connection
        std::vector<char> connMsgType(remote_client_idbuff.begin(),remote_client_idbuff.begin() + 1);
        connectMessageType enumconnMsgType = (connectMessageType) bytesToInt(connMsgType);

        //the remote computer os
        //The type of connection
        std::vector<char> connRemoteComputerOS(remote_client_idbuff.begin() + 1,remote_client_idbuff.begin() + 2);
        setRemoteComputerOS((OS)bytesToInt(connRemoteComputerOS));

        if(enumconnMsgType == connectMessageType::proxy){
            //receive the first byte that shows the size of ID of the remote computer
            std::vector<char> idSize(remote_client_idbuff.begin() + 2,remote_client_idbuff.begin() + 3);
            int iIDSize = bytesToInt(idSize);

            //once we have the length of id, we get the id in vector
            std::vector<char> vremoteID(remote_client_idbuff.begin() + 3, remote_client_idbuff.begin() + 3 + iIDSize);

            //Then we get the password size
            std::vector<char> pwdSize(remote_client_idbuff.begin() + 3 + iIDSize,remote_client_idbuff.begin() + 3 + iIDSize + 1);
            int ipwdSize = bytesToInt(pwdSize);

            //receive the password
            std::vector<char> vpassword(remote_client_idbuff.begin() + 3 + iIDSize + 1, remote_client_idbuff.begin() + 3 + iIDSize + 1 + ipwdSize);

            //receive the ip address the client who wants to connect
            std::vector<char> vclientIP(remote_client_idbuff.begin() + 3 + iIDSize + 1 + ipwdSize, remote_client_idbuff.end());
            unsigned int iclientIP = bytesToInt(vclientIP);

            //Check if IP banned
            if (isIPBannedForWrongPasswords(iclientIP))
                return;

            //check if the password sent is the same password that the client has
            std::string passwdQuestion(vpassword.begin(),vpassword.end());
            if (passwdQuestion == this->password){

                //The sent password is correct
                std::cout << "Client connection accepted. Remote Client ID: "<< remote_client_idbuff.data() << std::endl;

                //Reset to password protection for the specific ip
                resetWrongPasswordIPProtection(iclientIP);

                setConnectionState(connectedWithOtherAsServer);

                _sendmsg(this->getActiveSocket(), CMD_ACCEPT, vremoteID);//>-------------for this particular server accept the KRemote request, sending the remote id
                //std::vector<char> emtpyv;
                emit sig_messageRecieved(MSG_REMOTE_CLIENT_ACCEPTED, remote_client_idbuff);
            } else {
                //the password sent is wrong
                //get from the vector the ip of client
                addWrongPasswordIPProtection(iclientIP);
            }
        } // if connectMessageType::proxy
    } // CMD_CONNECT

    // the password is not correct command
    else if(command == CMD_CONNECT_PASSWORD_NOT_CORRECT){
        emit sig_messageRecieved(MSG_CONNECT_PASSWORD_NOT_CORRECT);
    }


    // Banned passwords connection attempts command
    else if(command == CMD_BAN_IP_WRONG_PWD){
        emit sig_messageRecieved(MSG_BAN_IP_WRONG_PWD);
    }

    // Banned passwords connection attempts warning command
    // syndesis dinontas lathos password
    else if(command == CMD_WARNING_BAN_IP_WRONG_PWD){
        //Get remain tries
        std::vector<char> remain_tries_buff(1);
        int bytes_received = _receivePlain(this->getActiveSocket(),remain_tries_buff);

        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_WARNING_BAN_IP_WRONG_PWD, remain_tries_buff);
    }

    // No connection requested
    else if(command == CMD_CONNECT_ID_NOT_FOUND){
        std::vector<char> emtpyv;
        emit sig_messageRecieved(MSG_CONNECT_ID_NOT_FOUND, emtpyv);
    } //CMD_CONNECT_ID_NOT_FOUND

    //Connection accepted command
    else if(command == CMD_ACCEPT)
    {
        std::vector<char> remote_client_id_buff;
        _receive(this->getActiveSocket(),remote_client_id_buff); //<-----------to remote client id

        setConnectionState(connectionState::connectedWithOtherAsClient);

        //std::vector<char> emptyv;
        emit sig_messageRecieved(MSG_CONNECTION_ACCEPTED, remote_client_id_buff);
    }

    else if(command == CMD_DISCONNECT_FROM_REMOTE_COMPUTER)
    {
        setConnectionState(connectionState::connectedWithProxy);
        emit sig_messageRecieved(MSG_REMOTE_COMPUTER_DISCONNECTED);

    }

    //Request screenshot command
    else if(command == CMD_REQUEST_SCREENSHOT)
    {
       // qDebug("Request screenshot.");

        std::vector<char> emptyv;
        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_SCREENSHOT_REQUEST,emptyv);
    } // CMD_REQUEST_SREENSHOT

    else if(command == CMD_REQUEST_SCREENSHOT_DIFF)
    {
        //Get the request
        std::vector<char> screenshot_diff_id_data_buff;
        int bytes_recieved = _receive(this->getActiveSocket(),screenshot_diff_id_data_buff);
        std::string rid(screenshot_diff_id_data_buff.begin(),screenshot_diff_id_data_buff.end());

        //qDebug ("4. CMD_REQUEST_SCREENSHOT_DIFF ID: %s. Receive and send request screenshot diff. Will emit signal from protocol to ui. Bytes recv: %i",rid.c_str(),bytes_recieved);
        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_SCREENSHOT_DIFF_REQUEST,screenshot_diff_id_data_buff);
    } // CMD_REQUEST_SCREENSHOT_DIFF


    //Screenshot command
    else if(command == CMD_SCREENSHOT)
    {
        RequestScreenshotDiff();
        std::vector<char> screenshot_data_buff;
        int bytes_received = _receive(this->getActiveSocket(),screenshot_data_buff);
        //qDebug("Screenshot recieved! tΒotal bytes: %i",bytes_received);
        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_SCREENSHOT,screenshot_data_buff);
    }//CMD_SCREENSHOT

    //Screenshot_diff command
    else if(command == CMD_SCREENSHOT_DIFF)
    {
        RequestScreenshotDiff();
        std::vector<char> screenshot_diff_data_buff;
        int bytes_received = _receive(this->getActiveSocket(),screenshot_diff_data_buff);
        //qDebug("DS.1 Diff screenshot recieved! Total bytes: %i. will emit to UI.",bytes_received);

        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_SCREENSHOT_DIFF,screenshot_diff_data_buff);
    }//CMD_SCREENSHOT_DIFF

    //Mouse command
    else if(command == CMD_MOUSE)
    {
        std::vector<char> mouse_data_buff(10);
        int bytes_received = _receivePlain(this->getActiveSocket(),mouse_data_buff);

        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_MOUSE,mouse_data_buff);
    }// send mouse

    //Keyboard command
    else if(command == CMD_KEYBOARD)
    {
        std::vector<char> keyboard_data_buff(6);
        int bytes_received = _receivePlain(this->getActiveSocket(),keyboard_data_buff);

        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_KEYBOARD,keyboard_data_buff);
        int received_code = bytesToInt(keyboard_data_buff);

        std::cout<<"Key code :"<<received_code;
    }// CMD_KEYBOARD

    else if(command == CMD_WARNING_BAN_IP_WRONG_ID)
    {
        std::vector<char> warn_remaining_tries_data_buff(1);
        int bytes_received = _receivePlain(this->getActiveSocket(), warn_remaining_tries_data_buff);

        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_WARNING_BAN_IP_WRONG_ID,warn_remaining_tries_data_buff);
    }// CMD_WARNING_BAN_IP_WRONG_ID

    else if(command == CMD_BAN_IP_WRONG_ID)
    {
        std::vector<char> ban_remaining_sec_data_buff(4);
        int bytes_received = _receivePlain(this->getActiveSocket(),ban_remaining_sec_data_buff);

        //std::vector<char> cdata;
        emit sig_messageRecieved(MSG_BAN_IP_WRONG_ID,ban_remaining_sec_data_buff);
    }// CMD_BAN_IP_WRONG_ID

    else if(command == CMD_ERROR_APP_VERSION_NOT_ACCEPTED)
    {
        std::vector<char> vurl;
        int bytes_received = _receive(this->getActiveSocket(),vurl);
        emit sig_messageRecieved(MSG_ERROR_APP_VERSION_NOT_ACCEPTED,vurl);
    } // CMD_ERROR_APP_VERSION_NOT_ACCEPTED

    else
    {
        qDebug ("---->>  COMMAND NOT FOUND : %s", command);
    }
}

//Detecting endianness programmatically in a C++ program
//http://stackoverflow.com/questions/1001307/detecting-endianness-programmatically-in-a-c-program
void displayEndianness()
{
    if ( htonl(47) == 47 ) {
        qDebug("Big endian");
    } else {
        qDebug("Little endian");
    }
}

void clientserver::start_protocol()
{
        int bytes_recv;
        struct sockaddr_in serv_addr;
        struct hostent *SERVER;

        diffRequestCounter = 0;

        #ifdef WIN32
            // Initialize Winsock
            int iResult;
            WSADATA wsaData;
            iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
            if (iResult != 0) {
                std::cout << "WSAStartup failed: " << iResult << std::endl;
                return;
            }
        #endif

        this->setActiveSocket(socket(AF_INET, SOCK_STREAM, 0));
#ifdef WIN32
        if (this->getActiveSocket() == INVALID_SOCKET) {
#else
        if (this->getActiveSocket() < 0){
#endif
            error("ERROR opening socket");
            return;
        }

        //SERVER = gethostbyname("mailgate.filoxeni.com");
        //SERVER = gethostbyname("mail.pixarina.com");
        SERVER = gethostbyname("kpc");

        if (SERVER == NULL) {
            emit sig_messageRecieved(MSG_NO_INTERNET_CONNECTION);
            fprintf(stderr,"ERROR, no such host\n");

#ifdef WIN32
            closesocket(this->getActiveSocket());
#else
            close(this->getActiveSocket());
#endif

            //Sleep for 1 second
            std::chrono::milliseconds sleep_dura(1000);
            std::this_thread::sleep_for(sleep_dura);

            //rings if there is not internet connection
            return;
            //exit(0);
        }

        memset((char *) &serv_addr,0, sizeof(serv_addr));
        serv_addr.sin_family = AF_INET;


        bcopy((char *)SERVER->h_addr,
             (char *)&serv_addr.sin_addr.s_addr,
             SERVER->h_length);

        //serv_addr.sin_addr.s_addr=inet_addr("192.168.32.20"); // <------------- local server

        //IMPORTANT: do disable the nagle algorithm. reduces the latency.
        int flag = 1;
        setsockopt(this->getActiveSocket(),      /* socket affected */
                                IPPROTO_TCP,     /* set option at TCP level */
                                TCP_NODELAY,     /* name of option */
                                (char *) &flag,  /* the cast is historical cruft */
                                sizeof(int));    /* length of option value */

        serv_addr.sin_port = htons(PORT_NUMBER);
        if (::connect(this->getActiveSocket(),(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
        {
            qDebug("ERROR connecting ");
            sleep(1);


#ifdef WIN32
            closesocket(this->getActiveSocket());
#else
            close(this->getActiveSocket());
#endif
            emit sig_messageRecieved(MSG_NO_PROXY_CONNECTION);
            return;
         }

        qDebug("Remote Cotrol BETA - (c) 2017 Kad HARBI \n\n");
        displayEndianness();

        //Begin processing commands
        std::array<char,1> cmdbuffer;

        //set socket options
        //int send_timeout = 30000;
        //int intlen = sizeof(int);
       // setsockopt(this->getActiveSocket(), SOL_SOCKET, SO_SNDTIMEO, (char*)&send_timeout, intlen);
        //getsockopt(socketfd, SOL_SOCKET, SO_SNDTIMEO, (char*)&timeout, &ilen);

        while(true){
            try
            {
                //qDebug("1 -----> Waitting for command...");

                bytes_recv = recv(this->getActiveSocket(), &cmdbuffer[0], 1, 0);

                if (bytes_recv == 0){
                    std::cout << std::this_thread::get_id() << " " <<
                                 "######### --- Main command loop disconnected from server. ---- ########" << " " <<
                               "####  recv return 0 bytes. [MAIN command loop]. Returning from function." << std::endl;

        #ifdef WIN32
                    closesocket(this->getActiveSocket());
        #else
                    close(this->getActiveSocket());
        #endif
                    //emit sig_messageRecieved(MSG_NO_PROXY_CONNECTION);
                    emit sig_messageRecieved(MSG_REMOTE_COMPUTER_DISCONNECTED);

                    return;
                }
                else if (bytes_recv == -1){
                    displayErrno("void clientserver::start_protocol() ## bytes_recv == -1 ## [MAIN command loop]. Returning from function.");

        #ifdef WIN32
                    closesocket(this->getActiveSocket());
        #else
                    close(this->getActiveSocket());
        #endif
                    emit sig_messageRecieved(MSG_NO_PROXY_CONNECTION);

                    return;
                }

                //qDebug("2 -----> Command recieved: %s. Bytes: %i. Start processing the command",cmdbuffer.data(),bytes_recv);
                proccesCommand(cmdbuffer);

            }
            catch(std::exception& ex)
            {
                qDebug("----> EXCEPTION sto start_protocol ::: %s",ex.what());
                emit sig_exception(QString::fromUtf8(ex.what()));
            }
            catch(std::runtime_error& ex)
            {
                qDebug("----> EXCEPTION :: RUNTIME_ERROR sto start_protocol ::: %s",ex.what());
                emit sig_exception(QString::fromUtf8(ex.what()));
            }

            catch( ... )
            {
                qDebug("----> EXCEPTION :: start_protocol unhundled exception");
            }

        } // while


        #ifdef WIN32
        //closesocket(sockfd);
        #else
        //close(sockfd);
        #endif
        return;

}
