/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#include "About.h"
#include "ui_About.h"

About::About(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::About)
{
    ui->setupUi(this);

#if  defined Q_OS_WIN || defined Q_OS_LINUX
    QFont lblAppNameFont = ui->lblAppName->font();
    lblAppNameFont.setPointSize(lblAppNameFont.pointSize() * 0.9);

    QFont lblCopyrightFont = ui->lblCopyright->font();
    lblCopyrightFont.setPointSize(lblCopyrightFont.pointSize() * 0.9);

    ui->lblAppName->setFont(lblAppNameFont);
    ui->lblCopyright->setFont(lblCopyrightFont);
    ui->lblVersion->setFont(lblCopyrightFont);
    //ui->txtLicense->setFont(lblCopyrightFont);
    ui->txtLicense->setHtml(ui->txtLicense->toHtml().replace("12pt","10pt"));
#endif

    ui->lblAppName->setText(QGuiApplication::applicationName());
    QString version(APP_VERSION);
    ui->lblVersion->setText("Version " + version + " Alpha");
}

About::~About()
{
    delete ui;
}
