/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#ifndef KEEPALIVE_H
#define KEEPALIVE_H

#include <QThread>
#include <thread>
#include <atomic>
#include <chrono>
#include "clientserver.h"

class keepalive : public QThread
{
        Q_OBJECT
public:
    clientserver * protocol;

protected:
    void run(void);

private:
    std::chrono::high_resolution_clock::time_point _lastHeartBeat;
    void setLastHeartBeat(std::chrono::high_resolution_clock::time_point timepoint);
    std::chrono::high_resolution_clock::time_point getLastHeartBeat();
};

#endif
