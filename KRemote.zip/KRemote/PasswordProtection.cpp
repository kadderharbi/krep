#include "PasswordProtection.h"

PasswordProtection::PasswordProtection()
{
}
