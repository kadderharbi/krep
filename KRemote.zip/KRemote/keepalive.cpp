/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#include "keepalive.h"

/*
 * i This class has 2 targets:
 * 1. Sends heart bit to server to keep alive
 * 2. Try to restore intrrupted connection with the server
 *
 * The server will send a heart beat every 30 seconds, the server will have a period of 90 seconds
 */

const int HEARTBEAT_RATE = 30; //seconds (default 30)


void keepalive::run(void){
    std::chrono::milliseconds sleep_dura(1000);
    setLastHeartBeat(std::chrono::high_resolution_clock::now());

    while (true){
        std::chrono::high_resolution_clock::time_point curr_time = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> time_span = std::chrono::duration_cast<std::chrono::duration<double>>(curr_time - getLastHeartBeat());

        if (time_span.count() >= HEARTBEAT_RATE)
        {
            if (protocol->getConnectionState() != connectionState::disconnected){
                try {
                    setLastHeartBeat(std::chrono::high_resolution_clock::now()); //Set the time before calling the heartbeat, so that inthe case of skeptics not to be called continuously the sendHeartBeat
                    if (protocol->isRunning()){
                        protocol->sendHeartBeat();
                    } else {
                        protocol->setConnectionState(connectionState::disconnected);
                        protocol->start();
                    }
                } catch (std::exception& ex) {
                //    //TODO: //Pro management of socket functioning.
                    protocol->setConnectionState(connectionState::disconnected);
                    //protocol->start();
                } catch ( ... ) {
                    protocol->setConnectionState(connectionState::disconnected);
                    //protocol->start();
                }
            }
        }
        std::this_thread::sleep_for(sleep_dura);
    }
}

void keepalive::setLastHeartBeat(std::chrono::high_resolution_clock::time_point timepoint)
{
    _lastHeartBeat = timepoint;
}

std::chrono::high_resolution_clock::time_point keepalive::getLastHeartBeat()
{
    return _lastHeartBeat;
}
