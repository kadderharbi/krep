/*
#ifndef APPNAPCONTROLLER_H
#define APPNAPCONTROLLER_H

#include <atomic>
#include <thread>
#include <untitled.h>
#include <chrono>
#include <iostream>

class AppNapController
{
public:
    AppNapController();

    static void DisableAppNap();
    static void EnableAppNap();
    static void DisableAppNapInNewThread();
    static void DisableAppNapInNewThreadChild();

private:
};

#endif // APPNAPCONTROLLER_H
*/
