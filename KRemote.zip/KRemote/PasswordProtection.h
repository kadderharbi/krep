/* ***********************************************************************
 * KRemote
 * (C) 2017 by Kad HARBI (kad@pixarina.com)
 *
 * ***********************************************************************/

#ifndef PASSWORDPROTECTION_H
#define PASSWORDPROTECTION_H

class PasswordProtection
{
public:
    PasswordProtection();
    int wrongIDCounter = 0;//The wrong ID counter
};

#endif
