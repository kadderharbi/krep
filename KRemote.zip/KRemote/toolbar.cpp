#include "toolbar.h"

ToolBar::ToolBar(QWidget *parent) : QWidget(parent,Qt::FramelessWindowHint | Qt::WindowSystemMenuHint|Qt::WindowStaysOnTopHint)
{
    this->setParent(parent);
    this->setGeometry(QRect(0,0,200,200));

}
