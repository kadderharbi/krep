#!/bin/bash
java -cp bin:lib/beansbinding-1.2.1.jar javax.ktest.apps.WinApp
