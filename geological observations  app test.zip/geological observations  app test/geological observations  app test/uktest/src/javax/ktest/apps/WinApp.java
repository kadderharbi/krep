package javax.ktest.apps;

import javax.swing.UIManager;
import javax.swing.plaf.metal.DefaultMetalTheme;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.ktest.controls.MainWindow;

/**
 * 
 * WinApp is the main application process
 * 
 * @author kadder
 *
 */

public class WinApp
{
    /**
     * Main Application Entry point
     * 
     * @param args
     */
    public static void main(String[] args)
    {

	// Main application process init and start
	new Thread()
	{
	    public void run()
	    {
		try
		{
		    // Just set controls theme
		    MetalLookAndFeel theme = new MetalLookAndFeel(); 
		    MetalLookAndFeel.setCurrentTheme(new DefaultMetalTheme());  
		    UIManager.setLookAndFeel(theme);
		    // Main window instance show
		    MainWindow window = new MainWindow(); 
		    window.frame.setVisible(true);
		} catch (Exception e)
		{
		    e.printStackTrace(); // if there is any exception
		}
	    }
	}.start();
    }
}
