package javax.ktest.tools;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * class ImageDrawer draws and scales image on a given control canvas
 * @author kadder
 *
 */

public class ImageDrawer { 
	
	/** static method to draw image of a given path on Graphics G with width and height
	 *  and scales it in the center of the graphics
	 * 
	 * @param path
	 * @param g
	 * @param width
	 * @param height
	 * @throws IOException
	 */

    public static void drawScaledImage(String path, Graphics g,int width,int height) throws IOException {
    	BufferedImage bImg = ImageIO.read(new File(path));
        int imgWidth = bImg.getWidth(null)/3;
        int imgHeight = bImg.getHeight(null)/3;       
        int posx= (width-imgWidth)/2;
        int posy= (height-imgHeight)/2-10;       
        g.drawImage(bImg,  posx, posy, imgWidth, imgHeight, null);        
    }
    
    /**
     * static method to clear the component canvas
     * @param canvas
     */   
    public static void clearImage(Component canvas){
    	Graphics g=canvas.getGraphics();
    	g.setColor(canvas.getBackground());
    	g.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }
}