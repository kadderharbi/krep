package javax.ktest.beans;

/**
 * Observation bean will contain relevant information about the Observation
 * 
 * @author kadder
 *
 */

public class Observation
{
    private String line; // string line that will contain input read data
    private String name; // Observation name
    private String type; // Observation type
    private double x; // Observation X location on the map
    private double y; // Observation Y location on the map
    private double z; // Observation Z depth
    private String date; // Observation date
    private String time; // Observation time
    private String recorderName; // Observation Recorder name
    private String recorderEmail; // Observation Recorder email
    private String extraLabel; // Observation extra label either {Borehole, Fossil, Rock, Measurement }
    private Object extra; // Oservation extra value depends of Observation type
    private String image; // Observation image if there exists

    /**
     * Observation constructor to initialize Observation object from given line
     * 
     * @param line
     *            contains raw data gotten from input file
     */
    public Observation(String line)
    {
	this.line = line;
	String[] arr = line.split("\\t", -1); // gets the words separated by tab char as showed in the given file
	this.name = arr[0];
	this.type = arr[1];
	this.x = Double.parseDouble(arr[2]);
	this.y = Double.parseDouble(arr[3]);
	this.z = Double.parseDouble(arr[4]);
	try
	{
	    this.date = arr[5];
	    this.time = arr[6];
	    System.out.println(date);
	} catch (Exception e)
	{
	}
	this.recorderName = arr[7];
	this.recorderEmail = arr[8];

	if (!arr[9].isEmpty())
	{
	    this.extra = arr[9];
	    this.extraLabel = "Drilled depth (m)";
	} else if (!arr[10].isEmpty())
	{
	    this.extra = arr[10];
	    this.extraLabel = "Species";
	} else if (!arr[11].isEmpty())
	{
	    this.extra = arr[11];
	    this.extraLabel = "Rock name";
	} else
	{
	    this.extra = arr[12];
	    this.extraLabel = "Porosity (Pt)";
	}

	this.image = arr[13];
    }

    /**
     * Gets Ovservation name
     * 
     * @return
     */
    public String getName()
    {
	return name;
    }

    /**
     * Gets Observation type
     * 
     * @return
     */
    public String getType()
    {
	return type;
    }

    /**
     * Gets X coordinate of Observation on the map
     * 
     * @return
     */
    public double getX()
    {
	return x;
    }

    /**
     * Gets Y coordinate of Observation on the map
     * 
     * @return
     */
    public double getY()
    {
	return y;
    }

    /**
     * Gets Z depth of Observation on the map
     * 
     * @return
     */
    public double getZ()
    {
	return z;
    }

    /**
     * Gets Observation date
     * 
     * @return
     */
    public String getDate()
    {
	return date;
    }

    /**
     * Gets Observation time
     * 
     * @return
     */
    public String getTime()
    {
	return time;
    }

    /**
     * Gets Observation Recorder name
     * 
     * @return
     */
    public String getRecorderName()
    {
	return recorderName;
    }

    /**
     * Gets Observation Recorder email
     * 
     * @return
     */
    public String getRecorderEmail()
    {
	return recorderEmail;
    }

    /**
     * Gets Observation Extra detail either { Borehole, Fossil, Rock name, Measurement }
     * 
     * @return
     */
    public Object getExtra()
    {
	return extra;
    }
    /**
     * Gets Observation Observation Detail label depends of Observation Extra detail {Borehole,Fossil,Rock,Measurement}
     * 
     * @return
     */
    public String getExtraLabel()
    {
	return extraLabel;
    }

    /**
     * Gets Observation Image
     * 
     * @return
     */
    public String getImage()
    {
	return image;
    }

   

}
