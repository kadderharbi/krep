package javax.ktest.controls;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.event.ActionEvent;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.border.TitledBorder;
import javax.swing.JCheckBox;
import javax.ktest.beans.Observation;
import javax.ktest.data.ObservationManager;
import javax.ktest.controls.MapPanel;
import javax.ktest.tools.ImageDrawer;
import javax.swing.border.CompoundBorder;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import org.jdesktop.beansbinding.BeanProperty;
import org.jdesktop.beansbinding.AutoBinding.UpdateStrategy;
import org.jdesktop.swingbinding.JTableBinding;
import org.jdesktop.swingbinding.SwingBindings;
import java.awt.Point;
import java.awt.Font;

/**
 * MainWindow class
 * 
 * @author kadder
 *
 */

@SuppressWarnings(value ={ "unchecked" })     //Suppress unchecked or unsafe operations  warnings
public class MainWindow
{

    // Main application frame
    public JFrame frame; // the main window frame
    private JTable table; // will contain observations list
    // Text fields used controls
    private JTextField obsNameTextField;
    private JTextField recorderTextField;
    private JTextField emailTextField;
    private JTextField typeTextField;
    // Panels used controls
    private JPanel imgPanel;
    private JPanel framePanel;
    private JPanel leftPanel;
    private JPanel mainPanel;
    private JPanel detailsPanel;
    private JLabel obsTypePanel;
    private JPanel obsPanel;
    private JPanel ctlPanel;
    private JPanel tablePanel;
    private JPanel gPanel;
    private JPanel glPanel;
    private JPanel pnlObservations;

    // Containers used controls
    private JTabbedPane tabbedPane;
    private GridBagLayout gbl_mainPanel;
    private GridBagConstraints gbc_leftPanel;
    private GridBagConstraints gbc_ObsPane;
    private GridBagLayout gbl_ObsPane;
    private GridBagConstraints gbc_ctlPanel;
    private GridBagLayout gbl_tablePanel;
    private GridBagConstraints gbcLabel;
    private JScrollPane scrollPane;
    private GridBagConstraints gbc_scrollPane;

    // Buttons usd controls
    private JButton searchButton;
    private JButton selectFossilsButton;
    // Labels used controls
    private JLabel obsLabel;
    private JLabel lblLabel;
    private JLabel emailLabel;
    private JLabel recorderLabel;

    private List<Observation> data; // will contain the list of observations to use
    private JTableBinding tableBinding; // Binding control between data and table
    private TableRowSorter<TableModel> rowsorter; // sorter used to sort table columns
    private ObservationManager obsManager; // Object to manage data

    // CheckBoxes used controls to check the fossils to draw on the map
    private JCheckBox fossilsCheckBox;
    private JCheckBox rocksCheckBox;
    private JCheckBox measmntsCheckBox;
    private JCheckBox boreholesCheckBox;
    private MapPanel gRightPanel;

    private String title="Test application";	// title will contain the text to display on the window titlebar
    /**
     * Main Window of the application
     */
    public MainWindow()
    {
	obsManager = ObservationManager.getInstance(); // Data manager instance
	this.data = obsManager.getObservations();
	initialize();
	PopulateTable(data);
	table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
	{
	    @Override
	    public void valueChanged(ListSelectionEvent e)
	    {
		if (!e.getValueIsAdjusting())
		{
		    try
		    {
			int rowIndex = table.getSelectedRow();
			Observation o = obsManager.getObservation(table.getModel().getValueAt(table.convertRowIndexToModel(rowIndex), 0).toString());
			obsManager.setCurrent(o.getName());
			obsTypePanel.setText(o.getExtraLabel());
			typeTextField.setText(o.getExtra().toString());
			recorderTextField.setText(o.getRecorderName());
			emailTextField.setText(o.getRecorderEmail());

			drawImage(o.getImage());
		    } catch (Exception ex)
		    {
			clear();
		    }
		}
	    }

	});

	setSorters(table);
	frame.setLocationRelativeTo(null);
    }

    // Sets sorter comparator for each column depends of column data type
    private void setSorters(JTable table)
    {	
	rowsorter = new TableRowSorter<TableModel>(table.getModel());
	table.setRowSorter(rowsorter);

	rowsorter.setComparator(2, new Comparator<Double>()
	{
	    @Override
	    public int compare(Double o1, Double o2)
	    {		
		return o1.compareTo(o2);
	    }
	});
	rowsorter.setComparator(3, new Comparator<Double>()
	{

	    @Override
	    public int compare(Double o1, Double o2)
	    {		
		return o1.compareTo(o2);
	    }
	});
	rowsorter.setComparator(4, new Comparator<Double>()
	{

	    @Override
	    public int compare(Double o1, Double o2)
	    {		
		return o1.compareTo(o2);
	    }
	});
	rowsorter.setComparator(5, new Comparator<String>()
	{

	    @Override
	    public int compare(String o1, String o2)
	    {
		try
		{		   
		    Date d1 = (new SimpleDateFormat("MM/dd/yyyy")).parse(o1);
		    Date d2 = (new SimpleDateFormat("MM/dd/yyyy")).parse(o2);
		    return d1.compareTo(d2);
		} catch (Exception e)
		{
		    return 0;
		}
	    }

	});
	rowsorter.setComparator(6, new Comparator<String>()
	{

	    @Override
	    public int compare(String o1, String o2)
	    {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
		try
		{
		    Date d1 = (Date) df.parse(o1);
		    Date d2 = (Date) df.parse(o2);		    
		    return d1.compareTo(d2);
		} catch (Exception e)
		{
		    //Date compare error exception caught here
		    System.out.println("Date compare error");
		}
		return 0;

	    }

	});

    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize()
    {
	frame = new JFrame();
	frame.setResizable(false);
	frame.setBounds(100, 100, 600, 300);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	JMenuBar menuBar = new JMenuBar();
	frame.setJMenuBar(menuBar);

	JMenu mnfile = new JMenu("File");
	menuBar.add(mnfile);

	JMenuItem miExit = new JMenuItem("Exit");
	miExit.addActionListener(new ActionListener()
	{
	    public void actionPerformed(ActionEvent e)
	    {
		System.exit(0);
	    }
	});
	mnfile.add(miExit);

	frame.setBounds(100, 100, 800, 400);
	frame.getContentPane().setLayout(new GridLayout(1, 1, 0, 0));

	framePanel = new JPanel();
	framePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
	framePanel.setBackground(UIManager.getColor("Button.focus"));
	frame.getContentPane().add(framePanel);
	framePanel.setLayout(new GridLayout(0, 1, 0, 0));

	tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	framePanel.add(tabbedPane);

	mainPanel = new JPanel();
	tabbedPane.addTab("Observations", mainPanel);
	gbl_mainPanel = new GridBagLayout();
	gbl_mainPanel.columnWidths = new int[]
	{ 323, 606, 0 };
	gbl_mainPanel.rowHeights = new int[]
	{ 292, 0 };
	gbl_mainPanel.columnWeights = new double[]
	{ 0.0, 0.0, Double.MIN_VALUE };
	gbl_mainPanel.rowWeights = new double[]
	{ 0.0, Double.MIN_VALUE };
	mainPanel.setLayout(gbl_mainPanel);

	leftPanel = new JPanel();
	leftPanel.setLayout(null);
	gbc_leftPanel = new GridBagConstraints();
	gbc_leftPanel.fill = GridBagConstraints.BOTH;
	gbc_leftPanel.insets = new Insets(0, 0, 0, 5);
	gbc_leftPanel.gridx = 0;
	gbc_leftPanel.gridy = 0;
	mainPanel.add(leftPanel, gbc_leftPanel);
	detailsPanel = new JPanel();
	detailsPanel.setSize(318, 300);
	detailsPanel.setLocation(new Point(0, 30));
	detailsPanel.setBorder(new TitledBorder(null, "Details", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	leftPanel.add(detailsPanel);
	detailsPanel.setLayout(null);

	imgPanel = new JPanel()
	{
	    @Override
	    public void paint(Graphics g)
	    {
		// TODO Auto-generated method stub
		super.paint(g);
		update(g);
	    }

	    @Override
	    public void update(Graphics g)
	    {
		try
		{
		    ImageDrawer.drawScaledImage(obsManager.getCurrent().getImage(), g, this.getWidth(), this.getHeight());
		} catch (Exception e)
		{
		}
	    }
	};
	imgPanel.setBorder(new CompoundBorder());
	imgPanel.setBackground(UIManager.getColor("CheckBox.background"));
	imgPanel.setBounds(5, 100, 305, 200);
	detailsPanel.add(imgPanel);
	imgPanel.setLayout(null);

	recorderLabel = new JLabel("Recorded by");
	recorderLabel.setFont(new Font("Dialog", Font.ITALIC, 11));
	recorderLabel.setBounds(12, 24, 93, 15);
	detailsPanel.add(recorderLabel);
	recorderLabel.setHorizontalAlignment(SwingConstants.RIGHT);

	recorderTextField = new JTextField();
	recorderTextField.setForeground(Color.BLUE);
	recorderTextField.setBounds(116, 22, 140, 19);
	detailsPanel.add(recorderTextField);
	recorderTextField.setMargin(new Insets(0, 5, 0, 0));
	recorderTextField.setHorizontalAlignment(SwingConstants.LEFT);
	recorderTextField.setAlignmentX(Component.RIGHT_ALIGNMENT);
	recorderTextField.setEditable(false);
	recorderTextField.setColumns(10);
	emailLabel = new JLabel("Email");
	emailLabel.setFont(new Font("Dialog", Font.ITALIC, 11));
	emailLabel.setBounds(55, 45, 48, 15);
	detailsPanel.add(emailLabel);
	emailLabel.setHorizontalAlignment(SwingConstants.RIGHT);
	emailTextField = new JTextField();
	emailTextField.setForeground(Color.BLUE);
	emailTextField.setBounds(116, 45, 190, 19);
	detailsPanel.add(emailTextField);
	emailTextField.setMargin(new Insets(0, 5, 0, 0));
	emailTextField.setHorizontalAlignment(SwingConstants.LEFT);
	emailTextField.setAlignmentX(Component.RIGHT_ALIGNMENT);
	emailTextField.setEditable(false);
	emailTextField.setColumns(10);
	typeTextField = new JTextField();
	typeTextField.setForeground(Color.BLUE);
	typeTextField.setBounds(116, 68, 126, 19);
	detailsPanel.add(typeTextField);
	typeTextField.setMargin(new Insets(0, 5, 0, 0));
	typeTextField.setHorizontalAlignment(SwingConstants.LEFT);
	typeTextField.setAlignmentX(Component.RIGHT_ALIGNMENT);
	typeTextField.setEditable(false);
	typeTextField.setColumns(10);
	obsTypePanel = new JLabel("Recorded by");
	obsTypePanel.setFont(new Font("Dialog", Font.ITALIC, 11));
	obsTypePanel.setBounds(4, 68, 103, 15);
	detailsPanel.add(obsTypePanel);
	obsTypePanel.setHorizontalAlignment(SwingConstants.RIGHT);

	obsPanel = new JPanel();
	obsPanel.setBackground(UIManager.getColor("Button.focus"));
	gbc_ObsPane = new GridBagConstraints();
	gbc_ObsPane.weighty = 1.0;
	gbc_ObsPane.weightx = 1.0;
	gbc_ObsPane.fill = GridBagConstraints.BOTH;
	gbc_ObsPane.gridx = 1;
	gbc_ObsPane.gridy = 0;
	mainPanel.add(obsPanel, gbc_ObsPane);
	gbl_ObsPane = new GridBagLayout();
	gbl_ObsPane.columnWidths = new int[]
	{ 467, 0 };
	gbl_ObsPane.rowHeights = new int[]
	{ 80, 219, 0 };
	gbl_ObsPane.columnWeights = new double[]
	{ 0.0, Double.MIN_VALUE };
	gbl_ObsPane.rowWeights = new double[]
	{ 0.0, 0.0, Double.MIN_VALUE };
	obsPanel.setLayout(gbl_ObsPane);
	ctlPanel = new JPanel();
	ctlPanel.setLayout(null);
	gbc_ctlPanel = new GridBagConstraints();
	gbc_ctlPanel.weightx = 1.0;
	gbc_ctlPanel.weighty = 1.0;
	gbc_ctlPanel.fill = GridBagConstraints.BOTH;
	gbc_ctlPanel.insets = new Insets(0, 0, 5, 0);
	gbc_ctlPanel.gridx = 0;
	gbc_ctlPanel.gridy = 0;
	obsPanel.add(ctlPanel, gbc_ctlPanel);

	obsLabel = new JLabel("Name:");
	obsLabel.setBounds(5, 10, 45, 15);
	ctlPanel.add(obsLabel);

	obsNameTextField = new JTextField();
	obsNameTextField.setBounds(55, 8, 114, 19);
	ctlPanel.add(obsNameTextField);
	obsNameTextField.setColumns(10);

	searchButton = new JButton("Search");
	searchButton.setBounds(174, 5, 83, 25);
	searchButton.addActionListener(new ActionListener()
	{
	    public void actionPerformed(ActionEvent e)
	    {

		if (obsNameTextField.getText().equals("*"))
		{
		    showAllData();
		    title="Test application";
		    frame.setTitle(title);
		    return;
		}

		data = obsManager.getObservations().stream().filter(o -> o.getName().equals(obsNameTextField.getText())).collect(Collectors.toList());
		if (data.size() > 0)
		{
		    refreshData();
		    table.getSelectionModel().setSelectionInterval(0, 0);
		    title="Test application";
		} else
		{
		    clear();
		    emailTextField.setText("");
		    recorderTextField.setText("");
		    typeTextField.setText("");
		    refreshData();
		    title="Nothing found";
		}
		frame.setTitle(title);
	    }

	    private void showAllData()
	    {
		// TODO Auto-generated method stub
		data = obsManager.getObservations();
		tableBinding.unbind();
		tableBinding.setSourceObject(data);
		tableBinding.bind();
		setSorters(table);
	    }

	});
	ctlPanel.add(searchButton);

	selectFossilsButton = new JButton("Select Fossils by Date/Time");
	selectFossilsButton.setBounds(5, 32, 252, 25);

	selectFossilsButton.addActionListener(new ActionListener()
	{
	    public void actionPerformed(ActionEvent e)
	    {
		// Select fossils by date/time
		data = obsManager.getFossils();
		refreshData();
		fitColumns();
		title="Test application";
		frame.setTitle(title);
	    };
	});

	ctlPanel.add(selectFossilsButton);
	tablePanel = new JPanel();
	GridBagConstraints gbc_tablePanel = new GridBagConstraints();
	gbc_tablePanel.fill = GridBagConstraints.BOTH;
	gbc_tablePanel.gridx = 0;
	gbc_tablePanel.gridy = 1;
	obsPanel.add(tablePanel, gbc_tablePanel);
	gbl_tablePanel = new GridBagLayout();
	gbl_tablePanel.columnWidths = new int[]
	{ 467, 0 };
	gbl_tablePanel.rowHeights = new int[]
	{ 0, 219, 0, 0 };
	gbl_tablePanel.columnWeights = new double[]
	{ 0.0, Double.MIN_VALUE };
	gbl_tablePanel.rowWeights = new double[]
	{ 0.0, 0.0, 0.0, Double.MIN_VALUE };
	tablePanel.setLayout(gbl_tablePanel);

	lblLabel = new JLabel("Observations");
	lblLabel.setHorizontalTextPosition(SwingConstants.LEFT);
	gbcLabel = new GridBagConstraints();
	gbcLabel.insets = new Insets(0, 0, 5, 0);
	gbcLabel.gridx = 0;
	gbcLabel.gridy = 0;
	tablePanel.add(lblLabel, gbcLabel);

	scrollPane = new JScrollPane();
	gbc_scrollPane = new GridBagConstraints();
	gbc_scrollPane.weighty = 1.0;
	gbc_scrollPane.weightx = 1.0;
	gbc_scrollPane.insets = new Insets(0, 0, 5, 0);
	gbc_scrollPane.fill = GridBagConstraints.BOTH;
	gbc_scrollPane.gridx = 0;
	gbc_scrollPane.gridy = 1;
	tablePanel.add(scrollPane, gbc_scrollPane);
	scrollPane.setBorder(new LineBorder(new Color(0, 0, 0)));
	scrollPane.setBackground(Color.ORANGE);
	table = new JTable()
	{
	    @Override
	    public boolean isCellEditable(int row, int column)
	    {
		// TODO Auto-generated method stub
		return false;
	    }

	};
	scrollPane.setViewportView(table);
	table.setBackground(Color.WHITE);

	gPanel = new JPanel();
	tabbedPane.addTab("Observations map", null, gPanel, null);
	gPanel.setLayout(new GridLayout(1, 2, 0, 0));

	glPanel = new JPanel();
	gPanel.add(glPanel);
	glPanel.setLayout(null);

	pnlObservations = new JPanel();
	pnlObservations.setBounds(64, 64, 260, 186);
	pnlObservations.setBorder(new TitledBorder(null, "Observations", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	glPanel.add(pnlObservations);
	pnlObservations.setLayout(null);

	fossilsCheckBox = new JCheckBox("Fossils");
	fossilsCheckBox.setName("cbfs");
	fossilsCheckBox.setForeground(new Color(0, 128, 0));
	fossilsCheckBox.setBounds(73, 70, 100, 23);
	pnlObservations.add(fossilsCheckBox);

	rocksCheckBox = new JCheckBox("Rocks");
	rocksCheckBox.setName("cbrk");
	rocksCheckBox.setForeground(new Color(128, 0, 0));
	rocksCheckBox.setBounds(73, 90, 100, 23);
	pnlObservations.add(rocksCheckBox);

	measmntsCheckBox = new JCheckBox("Measurements");
	measmntsCheckBox.setName("cbms");
	measmntsCheckBox.setForeground(new Color(0, 0, 128));
	measmntsCheckBox.setBounds(73, 110, 141, 23);
	pnlObservations.add(measmntsCheckBox);

	boreholesCheckBox = new JCheckBox("Boreholes");
	boreholesCheckBox.setName("cbbh");
	ChangeListener chlistener = new ChangeListener()
	{

	    @Override
	    public void stateChanged(ChangeEvent e)
	    {
		// TODO Auto-generated method stub
		// verify observations checkboxes states

	    }
	};
	boreholesCheckBox.addChangeListener(chlistener);
	boreholesCheckBox.setBounds(73, 50, 100, 23);
	pnlObservations.add(boreholesCheckBox);

	gRightPanel = new MapPanel(5, 5);
	gRightPanel.setBackground(UIManager.getColor("Button.background"));
	gPanel.add(gRightPanel);
	gRightPanel.setLayout(null);

	boreholesCheckBox.addActionListener(gRightPanel);
	fossilsCheckBox.addActionListener(gRightPanel);
	rocksCheckBox.addActionListener(gRightPanel);
	measmntsCheckBox.addActionListener(gRightPanel);

	frame.setTitle(title);
    }

    public void clear()
    {
	// TODO Auto-generated method stub
	ImageDrawer.clearImage(imgPanel);
    }

    public void PopulateTable(List<Observation> data)
    {
	tableBinding = SwingBindings.createJTableBinding(UpdateStrategy.READ_WRITE, data, table);
	BeanProperty name = BeanProperty.create("name");
	BeanProperty type = BeanProperty.create("type");
	BeanProperty x = BeanProperty.create("x");
	BeanProperty y = BeanProperty.create("y");
	BeanProperty z = BeanProperty.create("z");
	BeanProperty date = BeanProperty.create("date");
	BeanProperty time = BeanProperty.create("time");

	tableBinding.addColumnBinding(name).setColumnName("Name");
	tableBinding.addColumnBinding(type, "Type").setColumnName("Type");
	tableBinding.addColumnBinding(x, "X").setColumnName("X");
	tableBinding.addColumnBinding(y, "Y").setColumnName("Y");
	tableBinding.addColumnBinding(z, "Y").setColumnName("Z");
	tableBinding.addColumnBinding(date, "date").setColumnName("Date");
	tableBinding.addColumnBinding(time, "time").setColumnName("Time");
	tableBinding.bind();

	// fit column sizes
	fitColumns();

    }

    // Method to fit column widths
    private void fitColumns()
    {
	table.getColumnModel().getColumn(0).setPreferredWidth(30);
	table.getColumnModel().getColumn(1).setPreferredWidth(80);
	table.getColumnModel().getColumn(2).setPreferredWidth(30);
	table.getColumnModel().getColumn(3).setPreferredWidth(30);
	table.getColumnModel().getColumn(4).setPreferredWidth(30);
	table.getColumnModel().getColumn(5).setPreferredWidth(75);
    }

    public void refreshData()
    {
	tableBinding.unbind();
	tableBinding.setSourceObject(data);
	tableBinding.bind();
	setSorters(table);
    }

    // Draw relevant image on imgPanel panel
    private void drawImage(String path)
    {
	try
	{
	    ImageDrawer.clearImage(imgPanel);
	    ImageDrawer.drawScaledImage(path, imgPanel.getGraphics(), imgPanel.getWidth(), imgPanel.getHeight());
	} catch (Exception e)
	{
	    // draw nothing
	}
    }
}
