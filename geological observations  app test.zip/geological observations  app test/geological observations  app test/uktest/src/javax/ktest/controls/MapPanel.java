package javax.ktest.controls;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.ktest.beans.Observation;
import javax.ktest.data.ObservationManager;
import javax.swing.JCheckBox;
import javax.swing.JPanel;

/**
 * Class that will contain the map panel
 * 
 * @author kadder
 *
 */

public class MapPanel extends JPanel implements ActionListener
{

    // Map meters in x and y
    private int m_x;
    private int m_y;

    private int posx, posy; // The position where the map will be drawn on the graphics

    private int w, h; // Real width and height of the map on the graphics

    // Boolean conditions to control the checked and unchecked Observation types
    private boolean drawFossils = false;
    private boolean drawBorehols = false;
    private boolean drawRocks = false;
    private boolean drawMeasurements = false;

    private ObservationManager obsManager = ObservationManager.getInstance(); // Data manager instance

    /**
     * MapPanel constructor
     * 
     * @param m_x
     *            the length in meters horizontaly
     * @param m_y
     *            the length in meters vertically
     */
    public MapPanel(int m_x, int m_y)
    {	
	this.m_x = m_x;
	this.m_y = m_y;
    }

    /**
     * Overriden method to refresh map
     */
    @Override
    public void update(Graphics g)
    {
	draw(g);
    }

    /**
     * Overriden method to paint map
     */
    @Override
    public void paint(Graphics g)
    {
	super.paint(g);
	update(g);
    }

    /*
     * Draw map details
     * 
     * @param g graphics of the map
     */
    void draw(Graphics g)
    {
	w = m_x * ((this.getWidth() - 40) / m_x);
	h = m_y * ((this.getHeight() - 40) / m_y);

	posx = (this.getWidth() - w) / 2;
	posy = (this.getHeight() - h) / 2;

	// Draw main rectangle with red color
	g.setColor(Color.red);
	g.drawRect(posx, posy, w, h);

	// Draw reference with blue color
	g.setColor(Color.blue);
	g.drawString("0", 7, getHeight() - 5);
	g.drawString("500m", getWidth() - 40, getHeight() - 5);
	Graphics2D g2d = (Graphics2D) g.create();
	g2d.rotate(-Math.PI / 2, 13, 30);
	g2d.drawString("500m", 0, 30);
	g.drawLine(30, getHeight() - 10, getWidth() - 50, getHeight() - 10);
	g.drawLine(10, getHeight() - 30, 10, 50);

	// Divide the main rectangle into 100mx100m size each squares to represent the full map
	int xstep = (w) / m_x;
	int ystep = (h) / m_y;

	for (int i = xstep; i < w; i += xstep)
	    g.drawLine(posx + i, posy, posx + i, h + posy);

	for (int j = ystep; j < h; j += ystep)
	    g.drawLine(posx, j + posy, w + posx, posy + j);

	// Draw checked Observations
	if (drawBorehols)
	    drawBoreholes(g);
	if (drawFossils)
	    drawFossils(g);
	if (drawRocks)
	    drawRocks(g);
	if (drawMeasurements)
	    drawMeasurements(g);

    }

    /*
     * Draw observation at position (x,y) given
     * 
     * @param g graphics of the map where the Observation will be painted
     * 
     * @param color Color used to draw the observation
     * 
     * @param name name of the observation
     * 
     * @param x X location of observation
     * 
     * @param y Y location of observation
     */
    private void drawObservation(Graphics g, Color color, String name, int x, int y)
    {
	// The numeric values are calculated approximately just to fit the drawing
	g.setColor(color);
	int xx = x * (w / m_x) / 100 + posx - 10;
	int yy = ((500 - y) * (h / m_y) / 100 + posy - 10);
	g.drawRect(xx, yy, 20, 20);
	g.setColor(color);
	g.drawLine(xx + 5, yy + 5, xx + 15, yy + 15);
	g.drawLine(xx + 5, yy + 15, xx + 15, yy + 5);
	g.setColor(color);
	g.drawString(name, xx + 3, yy - 2);
    }

    /**
     * Draw Borehole observations
     * 
     * @param g
     *            Map canvas
     */
    void drawBoreholes(Graphics g)
    {
	// Get the list of boreholes
	List<Observation> boreholes = obsManager.getObservationsByType("Borehole");
	// and
	for (Observation bh : boreholes)
	    drawObservation(g, Color.black, bh.getName(), (int) bh.getX(), (int) bh.getY());
    }

    /**
     * Draw Rock observations
     * 
     * @param g
     *            Map canvas
     * 
     */
    void drawRocks(Graphics g)
    {
	// Get the list of rocks
	List<Observation> rocks = obsManager.getObservationsByType("Rock");
	// and
	for (Observation r : rocks)
	    drawObservation(g, new Color(255, 0, 0), r.getName(), (int) r.getX(), (int) r.getY());
    }

    /**
     * Draw Fossils observations
     * 
     * @param g
     *            Map canvas
     * 
     */
    void drawFossils(Graphics g)
    {
	// Get the list of fossils
	List<Observation> fossils = obsManager.getObservationsByType("Fossil");
	// and
	for (Observation f : fossils)
	    drawObservation(g, new Color(0, 100, 0), f.getName(), (int) f.getX(), (int) f.getY());
    }

    /**
     * Draw measurement observations
     * 
     * @param g
     *            Map canvas
     */
    void drawMeasurements(Graphics g)
    {
	// Get the list of measurements
	List<Observation> ms = obsManager.getObservationsByType("Measurement");
	// and
	for (Observation m : ms)
	    drawObservation(g, Color.blue, m.getName(), (int) m.getX(), (int) m.getY());
    }

    /**
     * actionPerformed method implementation( listeneing to checkbox controls )
     */
    @Override
    public void actionPerformed(ActionEvent e)
    {

	String name = ((JCheckBox) e.getSource()).getName(); // Get the checked control

	// Treat each case
	switch (name)
	{
	case "cbbh":
	    drawBorehols = ((JCheckBox) e.getSource()).isSelected();
	    break;
	case "cbfs":
	    drawFossils = ((JCheckBox) e.getSource()).isSelected();
	    break;
	case "cbrk":
	    drawRocks = ((JCheckBox) e.getSource()).isSelected();
	    break;
	case "cbms":
	    drawMeasurements = ((JCheckBox) e.getSource()).isSelected();
	    break;
	}

	this.repaint(); // Refresh the drawing
    }

}
