package javax.ktest.data;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.ktest.beans.Observation;
import java.text.SimpleDateFormat;

/**
 * ObservationManager class to retrieve Observations data from input and manage the data
 * 
 * @author kadder
 *
 */

public class ObservationManager {
	private FileInputStream fis;							// Input stream to read data into
	java.util.List<Observation> observations = null;		// Observation list that will contain data as a List of Observations
	private String current; 								// The current selected Observation in the list
	
	/**
	 * Gets the current selected Observation
	 * @return
	 */
	public Observation getCurrent() {
		//using lambda expressions o filter it 
		return (Observation)this.observations.stream().filter(o->o.getName().equals(current)).findFirst().get();		
	}

	/**
	 * Sets the current selected Observation
	 * @param name
	 */
	public void setCurrent(String name) {
		current=name;
	}

	/**
	 * The one and only one instance of ObservationManager class 
	 */
	public static ObservationManager instance = null;

	
	
	// Protect constructor for one and only one instance
	private ObservationManager() {
		try{observations = readData();}catch(Exception e){}
	}

	/**
	 * Gets the only and only one of DataManager instance
	 * @return
	 */
	public static ObservationManager getInstance() {
		if (instance == null)
			instance = new ObservationManager();
		return instance;
	}

	// Reads data from device to memory
	private List<Observation> readData() throws IOException {
		
		//Reads the data file, traverse the file and copies the data to ObservationList till the end of file
		List<Observation> vect = new ArrayList<Observation>();
		String path = new java.io.File(".").getCanonicalPath();
		BufferedReader br = new BufferedReader(new FileReader(path
				+ "/Data.txt"));
		ArrayList<Object> words = null;
		br.readLine();
		for (String line; (line = br.readLine()) != null;) {			
			Observation o =new Observation(line);			
			vect.add(o);			
		}
		return vect;
	}

	
	
	/**
	 * Searches for observation by index
	 * @param index
	 * @return
	 */
	public Observation getObservation(int index) {
		return observations.get(index);
	}

	/**
	 * Searches for observation by name
	 * @param name
	 * @return
	 */
	public Observation getObservation(String name) {
		for(Observation o : observations)
			if(o.getName().equals(name))
				return o;
		return null;
	}

	/**
	 * Gets the list of Observations
	 * @return
	 */
	
	public List<Observation> getObservations() {
		return observations;
	}
	
	/**
	 * Gets the list of Observations by type
	 * @param type
	 * @return
	 */
	public List<Observation> getObservationsByType(String type){
		List<Observation> tmpvect = observations.parallelStream().filter(o->o.getType().equals(type)).collect(Collectors.toList());		
		return tmpvect;		
	}	
	
	
	/**
	 * Gets Observations list of type Fossil 
	 * @return
	 */
	public List<Observation> getFossils(){
		List<Observation> fossils =getObservationsByType("Fossil");
		
		//Sorts the list by date/time top down
		Collections.sort(fossils,new Comparator<Observation>() {

			@Override
			public int compare(Observation o1, Observation o2) {				
				try{
				// Concatenates date  & time Strings    
				String d1str = o1.getDate()+" "+o1.getTime();
				String d2str = o2.getDate()+" "+o2.getTime();
				
				// Creates dates from date & time Strings concatenation  
				Date d1 = (new SimpleDateFormat("MM/dd/yyyy HH:mm:ss")).parse(d1str);
				Date d2 = (new SimpleDateFormat("MM/dd/yyyy HH:mm:ss")).parse(d2str);
				
											
				return d2.compareTo(d1);
				}catch(Exception e){
					return 0;
				}
			}
			
		});
		return fossils;
		
	}
	

	
}
